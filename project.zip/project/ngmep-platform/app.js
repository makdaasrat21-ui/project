/* ==========================================================================
   NGMEP — Application Coordinator & UI Controller
   ========================================================================== */

// Startup Event
window.addEventListener("DOMContentLoaded", () => {
    // 1. Initialize custom pseudo-3D canvas engine
    let canvas = document.getElementById("engineCanvas");
    if (canvas) {
        initEngine(canvas);
    }

    // 2. Multi-tenant project load (API or local)
    if (typeof initTenancy === "function") {
        initTenancy().then(() => {
            if (typeof updateApiStatusIndicator === "function" && typeof isApiEnabled === "function") {
                updateApiStatusIndicator(isApiEnabled());
            }
        });
    } else {
        loadModule("geometry");
    }

    // 3. Initialize User Manual tabs
    switchManualTab("overview");

    // 4. Setup global keybindings
    window.addEventListener("keydown", handleGlobalKeybindings);
});

/**
 * Handles module switching and UI panel adjustments
 */
function loadModule(name) {
    activeEngine = name;

    if (typeof setModuleState === "function") {
        setModuleState(name, "loading");
        setTimeout(() => {
            const btn = document.getElementById(`btn-${name}`);
            if (btn && btn.dataset.state === "loading") {
                setModuleState(name, "idle");
            }
        }, 900);
    }

    // Update active navbar sidebar highlight state
    let buttons = document.querySelectorAll(".module-btn");
    buttons.forEach(btn => {
        btn.classList.remove("active");
    });
    
    let activeBtn = document.getElementById(`btn-${name}`);
    if (activeBtn) activeBtn.classList.add("active");

    // Update Viewport Title HUD
    let titleEl = document.getElementById("viewportTitle");
    if (titleEl) {
        titleEl.innerText = getModuleFriendlyName(name);
    }
    if (typeof updateViewportProjectHUD === "function") updateViewportProjectHUD();

    // Dynamically inject parameters widgets for the selected module
    injectParameters(name);
}

function getModuleFriendlyName(name) {
    const commodity = (typeof getActiveProject === "function" && getActiveProject())
        ? getActiveProject().commodity : "Au";
    switch (name) {
        case "geometry": return "GEOMETRY CAD KERNEL";
        case "geology": return "GEOLOGICAL STRATIGRAPHY MODEL";
        case "blockmodel": return `BLOCK MODEL ESTIMATION (${commodity})`;
        case "engineering": return "MINE DESIGN & HAUL ROADS";
        case "simulation": return "TRUCK HAULAGE PHYSICS SIMULATION";
        case "economics": return "PROJECT ECONOMICS TELEMETRY";
        default: return "DIGITAL TWIN WORKSPACE";
    }
}

/**
 * Dynamically updates sidebar controls
 */
function injectParameters(moduleName) {
    let container = document.getElementById("moduleParams");
    if (!container) return;

    let html = "";

    if (moduleName === "geometry") {
        html = `
            <div class="param-group">
                <div class="param-header">
                    <span class="p-label">Mesh Grid Divisions</span>
                    <span class="p-val" id="lbl-mesh-res">${geomMeshRes}x${geomMeshRes}</span>
                </div>
                <input type="range" class="param-slider" id="param-mesh-res" min="5" max="40" value="${geomMeshRes}" oninput="updateParam('mesh-res', this.value)">
            </div>
            <div class="param-group">
                <div class="param-header">
                    <span class="p-label">Workspace Zoom Scale</span>
                    <span class="p-val" id="lbl-zoom">${zoom.toFixed(1)}x</span>
                </div>
                <input type="range" class="param-slider" id="param-zoom" min="2" max="50" value="${zoom*10}" oninput="updateParam('zoom', this.value/10)">
            </div>
            <button class="param-btn" onclick="triggerResetView()">🏠 Reset Camera View</button>
        `;
    } 
    
    else if (moduleName === "geology") {
        html = `
            <div class="param-group">
                <div class="param-header">
                    <span class="p-label">Stratigraphy Section Offset</span>
                    <span class="p-val" id="lbl-slice-offset">${geologySliceOffset}m</span>
                </div>
                <input type="range" class="param-slider" id="param-slice-offset" min="-120" max="120" value="${geologySliceOffset}" oninput="updateParam('slice-offset', this.value)">
            </div>
            <div class="toggle-group">
                <span class="p-label">Show Logging Drillholes</span>
                <label class="toggle-switch">
                    <input type="checkbox" id="param-show-boreholes" ${geologyShowBoreholes ? 'checked' : ''} onchange="updateParam('show-boreholes', this.checked)">
                    <span class="toggle-slider"></span>
                </label>
            </div>
        `;
    } 
    
    else if (moduleName === "blockmodel") {
        html = `
            <div class="param-group">
                <div class="param-header">
                    <span class="p-label">Est. Grade Cutoff (g/t Au)</span>
                    <span class="p-val" id="lbl-grade-cutoff">${blockGradeCutoff.toFixed(1)} g/t</span>
                </div>
                <input type="range" class="param-slider" id="param-grade-cutoff" min="0.0" max="4.5" step="0.1" value="${blockGradeCutoff}" oninput="updateParam('grade-cutoff', this.value)">
            </div>
            <div class="param-group">
                <span class="p-label">Estimation Algorithm</span>
                <div class="param-row">
                    <button class="param-btn active" onclick="alert('Algorithm locked: Ordinary Kriging Interpolator')">Kriging</button>
                    <button class="param-btn" onclick="alert('Nearest Neighbor estimator licensed in Pro Edition')">IDW</button>
                </div>
            </div>
        `;
    } 
    
    else if (moduleName === "engineering") {
        html = `
            <div class="param-group">
                <span class="p-label">Mine Shell Designs</span>
                <button class="param-btn active" style="width: 100%; margin-bottom: 8px;">Concentric Open-Pit Cone</button>
            </div>
            <div class="param-group">
                <span class="p-label">Geotechnical Constraints</span>
                <div class="param-row">
                    <button class="param-btn active" onclick="alert('Active Safety margins enabled')">Slope Stability</button>
                    <button class="param-btn" onclick="alert('Berm offsets configuration locked')">Berm Widths</button>
                </div>
            </div>
            <button class="param-btn" style="margin-top: 4px;" onclick="alert('Running Pit Slope hazard solver... OK. Safety factor margin is SF: 1.14')">⚠️ Run Slope Safety Solver</button>
            <button class="param-btn" style="margin-top: 6px; width: 100%; border-color: rgba(245,158,11,0.4);" onclick="triggerStopeOptimization()">⚡ Run Stope Optimization</button>
        `;
    } 
    
    else if (moduleName === "simulation") {
        html = `
            <div class="param-group">
                <div class="param-header">
                    <span class="p-label">CAT Hauler Fleet Count</span>
                    <span class="p-val" id="lbl-truck-count">${simTrucks.length} Units</span>
                </div>
                <input type="range" class="param-slider" id="param-truck-count" min="2" max="12" value="${simTrucks.length}" oninput="updateParam('truck-count', this.value)">
            </div>
            <button class="param-btn" onclick="resetSimulation()">🔄 Restart Dispatch Simulation</button>
        `;
    } 
    
    else if (moduleName === "economics") {
        html = `
            <div class="param-group">
                <div class="param-header">
                    <span class="p-label">Gold Spot Price ($/oz)</span>
                    <span class="p-val" id="lbl-gold-price">$${econGoldPrice}</span>
                </div>
                <input type="range" class="param-slider" id="param-gold-price" min="1000" max="3000" step="50" value="${econGoldPrice}" oninput="updateParam('gold-price', this.value)">
            </div>
            <div class="param-group">
                <div class="param-header">
                    <span class="p-label">Mining OPEX Cost ($/t)</span>
                    <span class="p-val" id="lbl-mining-cost">$${econMiningCost.toFixed(2)}</span>
                </div>
                <input type="range" class="param-slider" id="param-mining-cost" min="1.0" max="8.0" step="0.1" value="${econMiningCost}" oninput="updateParam('mining-cost', this.value)">
            </div>
            <div class="param-group">
                <div class="param-header">
                    <span class="p-label">Processing OPEX Cost ($/t)</span>
                    <span class="p-val" id="lbl-processing-cost">$${econProcessingCost.toFixed(2)}</span>
                </div>
                <input type="range" class="param-slider" id="param-processing-cost" min="5.0" max="35.0" step="0.5" value="${econProcessingCost}" oninput="updateParam('processing-cost', this.value)">
            </div>
        `;
    }

    container.innerHTML = html;
}

/**
 * Handles slider parameter bindings back to the engine parameters
 */
function updateParam(type, value) {
    if (type === "mesh-res") {
        geomMeshRes = parseInt(value);
        let lbl = document.getElementById("lbl-mesh-res");
        if (lbl) lbl.innerText = value + "x" + value;
    } 
    
    else if (type === "zoom") {
        zoom = parseFloat(value);
        let lbl = document.getElementById("lbl-zoom");
        if (lbl) lbl.innerText = zoom.toFixed(1) + "x";
        updateCameraHUD();
    } 
    
    else if (type === "slice-offset") {
        geologySliceOffset = parseInt(value);
        let lbl = document.getElementById("lbl-slice-offset");
        if (lbl) lbl.innerText = value + "m";
    } 
    
    else if (type === "show-boreholes") {
        geologyShowBoreholes = value;
    } 
    
    else if (type === "grade-cutoff") {
        blockGradeCutoff = parseFloat(value);
        let lbl = document.getElementById("lbl-grade-cutoff");
        if (lbl) lbl.innerText = blockGradeCutoff.toFixed(1) + " g/t";
    } 
    
    else if (type === "truck-count") {
        let count = parseInt(value);
        let lbl = document.getElementById("lbl-truck-count");
        if (lbl) lbl.innerText = count + " Units";
        
        // Resize simTrucks array smoothly
        if (count > simTrucks.length) {
            let diff = count - simTrucks.length;
            for (let i = 0; i < diff; i++) {
                simTrucks.push({
                    id: `TR-${101 + simTrucks.length}`,
                    progress: Math.random(),
                    capacity: 85,
                    load: 0,
                    status: "HAULING",
                    speed: 0.002 + Math.random() * 0.0005,
                    x: 0, y: 0, z: 0
                });
            }
        } else if (count < simTrucks.length) {
            simTrucks.splice(count);
        }
    } 
    
    else if (type === "gold-price") {
        econGoldPrice = parseInt(value);
        let lbl = document.getElementById("lbl-gold-price");
        if (lbl) lbl.innerText = "$" + value;
    } 
    
    else if (type === "mining-cost") {
        econMiningCost = parseFloat(value);
        let lbl = document.getElementById("lbl-mining-cost");
        if (lbl) lbl.innerText = "$" + econMiningCost.toFixed(2);
    } 
    
    else if (type === "processing-cost") {
        econProcessingCost = parseFloat(value);
        let lbl = document.getElementById("lbl-processing-cost");
        if (lbl) lbl.innerText = "$" + econProcessingCost.toFixed(2);
    }
}

/**
 * Handles global keypress operations
 */
function handleGlobalKeybindings(e) {
    // Ignore hotkeys when typing in input boxes
    if (document.activeElement.tagName === "INPUT" || document.activeElement.tagName === "TEXTAREA") {
        return;
    }

    // F1: Toggle User Manual
    if (e.key === "F1") {
        e.preventDefault();
        toggleManual();
    }

    // Esc: Close manual or overlay
    if (e.key === "Escape") {
        let panel = document.getElementById("manualPanel");
        if (panel && !panel.classList.contains("closed")) {
            panel.classList.add("closed");
            let triggerBtn = document.getElementById("manualTriggerBtn");
            if (triggerBtn) triggerBtn.style.display = "block";
        }
    }

    // Number keys 1-6 load modules
    if (e.key >= "1" && e.key <= "6") {
        let idx = parseInt(e.key);
        let modulesList = ["geometry", "geology", "blockmodel", "engineering", "simulation", "economics"];
        loadModule(modulesList[idx - 1]);
    }
}

/**
 * AI terminal dispatcher coordinator
 */
function runAI() {
    let inputEl = document.getElementById("aiInput");
    let outputEl = document.getElementById("aiOutput");
    if (inputEl && outputEl) {
        runAICommand(inputEl.value, loadModule, outputEl);
    }
}