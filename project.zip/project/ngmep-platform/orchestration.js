/* ==========================================================================
   NGMEP — Live Orchestration, Telemetry & Infrastructure Simulation
   ========================================================================== */

const PIPELINE_STAGES = [
    { id: "source", label: "Data Source", short: "SRC" },
    { id: "ai", label: "AI Agent", short: "AI" },
    { id: "compute", label: "Compute Engine", short: "CMP" },
    { id: "optimize", label: "Optimization", short: "OPT" },
    { id: "visualize", label: "Visualization", short: "VIS" },
    { id: "twin", label: "Digital Twin", short: "DTW" }
];

const MODULE_STATE_LABELS = {
    idle: "IDLE",
    loading: "LOADING",
    computing: "COMPUTING",
    syncing: "SYNCING",
    "ai-inference": "AI INFERENCE",
    distributed: "DISTRIBUTED",
    failed: "FAILED",
    recovering: "RECOVERING"
};

let moduleStates = {
    geometry: "idle",
    geology: "idle",
    blockmodel: "idle",
    engineering: "idle",
    simulation: "idle",
    economics: "idle"
};

let gpuNodes = [];
let simJobs = [];
let liveEvents = [];
let pipelineActive = false;
let pipelineStageIndex = -1;
let digitalTwinPulse = 0;
let scaleMetrics = {
    blocksIndexed: 2847391024,
    scanVolumePB: 1.847,
    activeMines: 7,
    cloudRegions: 4,
    gpuNodesOnline: 0,
    ingestRateMbps: 420
};

let orchestrationHeartbeat = null;

function initOrchestration() {
    seedGpuCluster();
    seedSimJobs();
    renderGpuTopology();
    renderSimQueue();
    renderGlobalOpsMap();
    const orgName = typeof getActiveOrg === "function" && getActiveOrg() ? getActiveOrg().name : "Organization";
    pushLiveEvent(`Orchestrator online — ${orgName} tenant mesh`, "success");
    const utm = typeof getActiveProject === "function" && getActiveProject() ? getActiveProject().utmZone : "50S";
    pushLiveEvent(`Telemetry bus: WGS84 / UTM ${utm} — field rigs streaming`, "info");

    orchestrationHeartbeat = setInterval(tickOrchestration, 1200);
    setInterval(tickFastTelemetry, 400);
    setInterval(simulateInfrastructureEvents, 8500);
    setInterval(renderLiveStreams, 500);
    setInterval(tickIdlePipelinePulse, 2000);

    const strip = document.getElementById("pipelineStrip");
    if (strip) strip.classList.add("idle-pulse");

    setModuleState("geometry", "syncing");
    setTimeout(() => setModuleState("geometry", "idle"), 2400);
    renderLiveStreams();
}

function tickIdlePipelinePulse() {
    const strip = document.getElementById("pipelineStrip");
    if (!strip || pipelineActive) return;
    const label = document.getElementById("pipelineStatusLabel");
    if (label && !pipelineActive) {
        const msgs = [
            "Orchestrator idle — mesh heartbeat OK",
            "Background kriging worker: 2 jobs queued",
            "Telemetry bus: 4.2k samples/s aggregate",
            "Render farm sync: all nodes nominal"
        ];
        label.textContent = msgs[Math.floor(Date.now() / 2000) % msgs.length];
    }
}

function renderLiveStreams() {
    const panel = document.getElementById("liveStreamPanel");
    if (!panel) return;

    const runningJobs = simJobs.filter(j => j.state === "running").length;
    const failedNodes = gpuNodes.filter(n => n.status === "failed").length;
    const avgGpu = gpuNodes.length
        ? gpuNodes.reduce((s, n) => s + (n.status === "online" ? n.util : 0), 0) / Math.max(1, scaleMetrics.gpuNodesOnline)
        : 0;

    const rows = [
        { label: "GPU cluster util", val: Math.round(avgGpu) + "%", warn: avgGpu > 85 },
        { label: "Drillhole ingest", val: scaleMetrics.ingestRateMbps + " Mb/s", active: true },
        { label: "Simulation jobs", val: runningJobs + " running", active: runningJobs > 0 },
        { label: "Block index", val: formatBillions(scaleMetrics.blocksIndexed), active: true },
        { label: "Scan archive", val: scaleMetrics.scanVolumePB.toFixed(3) + " PB", active: false },
        { label: "GPU nodes", val: scaleMetrics.gpuNodesOnline + "/" + gpuNodes.length, warn: failedNodes > 0 }
    ];

    panel.innerHTML = rows.map(r => `
        <div class="stream-row ${r.warn ? "warn" : ""} ${r.active ? "active" : ""}">
            <span class="stream-label">${r.label}</span>
            <span class="stream-val">${r.val}</span>
        </div>
    `).join("");
}

function updateAIAgentPanel(state, tasks) {
    const statusEl = document.getElementById("aiAgentState");
    const tasksEl = document.getElementById("aiAgentTasks");
    const wrap = document.querySelector(".ai-agent-status");
    if (statusEl) statusEl.textContent = state;
    if (wrap) wrap.classList.toggle("busy", state.indexOf("idle") === -1);
    if (tasksEl && tasks) {
        tasksEl.innerHTML = tasks.map(t => `
            <div class="ai-task-line ${t.done ? "done" : ""}">${t.text}</div>
        `).join("");
    }
}

function showAlertBanner(message, type = "info") {
    const el = document.getElementById("alertBanner");
    if (!el) return;
    el.textContent = message;
    el.className = `alert-banner ${type}`;
    el.classList.remove("hidden");
    document.body.classList.add("has-alert");
    clearTimeout(showAlertBanner._timer);
    showAlertBanner._timer = setTimeout(() => {
        el.classList.add("hidden");
        document.body.classList.remove("has-alert");
    }, 5000);
}

function appendAITerminal(text, typeClass) {
    const outputEl = document.getElementById("aiOutput");
    if (outputEl && typeof appendTerminalLine === "function") {
        appendTerminalLine(outputEl, text, typeClass || "system-msg");
    }
}

function seedGpuCluster(nodeCount) {
    seedGpuClusterForProject(nodeCount || 12);
}

function seedGpuClusterForProject(nodeCount) {
    const regions = ["ap-southeast-2", "us-west-2", "eu-central-1", "sa-east-1"];
    const types = ["A100", "H100", "L40S", "RTX 6000"];
    const count = Math.max(2, Math.min(24, nodeCount || 12));
    gpuNodes = [];
    for (let id = 1; id <= count; id++) {
        const ri = (id - 1) % regions.length;
        const region = regions[ri];
        const n = (id - 1) % 3;
        gpuNodes.push({
            id: `GPU-${String(id).padStart(3, "0")}`,
            region,
            type: types[(ri + n) % types.length],
            util: 35 + Math.random() * 40,
            vram: 72 + Math.floor(Math.random() * 8),
            queue: Math.floor(Math.random() * 4),
            cuda: Math.floor(Math.random() * 6) + 1,
            status: Math.random() > 0.15 ? "online" : "degraded",
            role: n === 0 ? "render" : n === 1 ? "simulation" : "kriging"
        });
    }
    scaleMetrics.gpuNodesOnline = gpuNodes.filter(n => n.status === "online").length;
}

function seedSimJobs() {
    const names = [
        "Stope-OPT-4412",
        "Pit-Shell-LG",
        "Fleet-DES-12",
        "Kriging-Au-L3",
        "Vent-CFD-09",
        "NPV-Monte-2k",
        "Render-Frame-Q",
        "CUDA-Mesh-12"
    ];
    simJobs = names.map((name, i) => ({
        name,
        progress: 20 + i * 11,
        gpus: 1 + (i % 3),
        eta: `${4 + i}m`,
        state: i === 2 ? "running" : i === 4 ? "queued" : "running"
    }));
}

function tickOrchestration() {
    digitalTwinPulse += 0.08;

    gpuNodes.forEach(node => {
        if (node.status === "failed") return;
        node.util = Math.max(8, Math.min(98, node.util + (Math.random() - 0.48) * 12));
        if (node.status === "degraded") node.util = Math.min(node.util, 55);
        node.queue = node.util > 80 ? Math.min(8, node.queue + 1) : Math.max(0, node.queue - (Math.random() > 0.6 ? 1 : 0));
    });

    simJobs.forEach(job => {
        if (job.state !== "running") return;
        job.progress = Math.min(100, job.progress + 2 + Math.random() * 5);
        if (job.progress >= 100) {
            job.state = "complete";
            pushLiveEvent(`Job ${job.name} completed — twin cache invalidated`, "success");
            setTimeout(() => {
                job.progress = 5 + Math.random() * 15;
                job.state = "running";
            }, 6000);
        }
    });

    scaleMetrics.blocksIndexed += Math.floor(800000 + Math.random() * 2400000);
    scaleMetrics.scanVolumePB += Math.random() * 0.00012;
    scaleMetrics.ingestRateMbps = 380 + Math.floor(Math.random() * 180);

    if (!pipelineActive) {
        rotateAmbientModuleActivity();
    }

    updateScaleHUD();
    renderGpuTopology();
    renderSimQueue();
    updateModuleStateBadges();
}

function tickFastTelemetry() {
    const fpsEl = document.getElementById("fpsVal");
    const cpuEl = document.getElementById("cpuVal");
    const memEl = document.getElementById("memVal");
    const gpuEl = document.getElementById("gpuUtilVal");
    const ingestEl = document.getElementById("ingestVal");

    if (typeof fpsCounter !== "undefined" && fpsEl) {
        fpsEl.innerText = fpsCounter.toFixed(1);
    }

    const loadBoost = pipelineActive ? 18 : 0;
    const cpu = (3.5 + Math.random() * 4 + loadBoost + (activeEngine === "simulation" ? 8 : 0)).toFixed(1);
    if (cpuEl) cpuEl.innerText = cpu + "%";

    const mem = 1.05 + Math.random() * 0.35 + (pipelineActive ? 0.4 : 0);
    if (memEl) memEl.innerText = mem.toFixed(2) + " GB";

    const onlineCount = Math.max(1, gpuNodes.filter(n => n.status === "online").length);
    const avgGpu = gpuNodes.length
        ? gpuNodes.reduce((s, n) => s + (n.status === "online" ? n.util : 0), 0) / onlineCount
        : 42;
    if (gpuEl) gpuEl.innerText = Math.round(avgGpu) + "%";

    if (ingestEl) ingestEl.innerText = scaleMetrics.ingestRateMbps + " Mb/s";

    const statusEl = document.querySelector(".status-text");
    const dotEl = document.querySelector(".pulse-dot");
    const failed = gpuNodes.filter(n => n.status === "failed").length;
    const degraded = gpuNodes.filter(n => n.status === "degraded").length;
    if (statusEl && dotEl) {
        if (failed > 0) {
            statusEl.innerText = `${failed} NODE(S) DOWN — FAILOVER`;
            statusEl.style.color = "var(--color-red)";
            dotEl.style.background = "var(--color-red)";
            dotEl.style.boxShadow = "0 0 8px var(--color-red)";
        } else if (degraded > 0 || pipelineActive) {
            statusEl.innerText = pipelineActive ? "ORCHESTRATION ACTIVE" : "DEGRADED — RECOVERING";
            statusEl.style.color = "var(--color-amber)";
            dotEl.style.background = "var(--color-amber)";
            dotEl.style.boxShadow = "0 0 8px var(--color-amber)";
        } else {
            statusEl.innerText = "ENGINES ONLINE";
            statusEl.style.color = "var(--color-green)";
            dotEl.style.background = "var(--color-green)";
            dotEl.style.boxShadow = "0 0 8px var(--color-green)";
        }
    }
}

function rotateAmbientModuleActivity() {
    const keys = Object.keys(moduleStates);
    const idleMods = keys.filter(k => moduleStates[k] === "idle");
    if (!idleMods.length) return;
    const pick = idleMods[Math.floor(Math.random() * idleMods.length)];
    const transient = ["computing", "syncing", "distributed"][Math.floor(Math.random() * 3)];
    setModuleState(pick, transient);
    setTimeout(() => {
        if (moduleStates[pick] === transient) setModuleState(pick, "idle");
    }, 2200 + Math.random() * 1800);
}

function setModuleState(moduleName, state) {
    if (!moduleStates[moduleName]) return;
    moduleStates[moduleName] = state;
    updateModuleStateBadges();

    const btn = document.getElementById(`btn-${moduleName}`);
    if (btn) {
        btn.dataset.state = state;
    }
}

function updateModuleStateBadges() {
    Object.keys(moduleStates).forEach(name => {
        const badge = document.getElementById(`state-${name}`);
        if (badge) {
            const st = moduleStates[name];
            badge.textContent = MODULE_STATE_LABELS[st] || st.toUpperCase();
            badge.className = `module-state-badge state-${st}`;
        }
    });
}

function updateScaleHUD() {
    const blocksEl = document.getElementById("scaleBlocks");
    const pbEl = document.getElementById("scalePB");
    const minesEl = document.getElementById("scaleMines");
    const regionsEl = document.getElementById("scaleRegions");
    const gpusEl = document.getElementById("scaleGpus");

    if (blocksEl) blocksEl.textContent = formatBillions(scaleMetrics.blocksIndexed);
    if (pbEl) pbEl.textContent = scaleMetrics.scanVolumePB.toFixed(3) + " PB";
    if (minesEl) minesEl.textContent = scaleMetrics.activeMines + " sites";
    if (regionsEl) regionsEl.textContent = scaleMetrics.cloudRegions + " regions";
    if (gpusEl) gpusEl.textContent = scaleMetrics.gpuNodesOnline + "/" + gpuNodes.length + " nodes";
}

function formatBillions(n) {
    if (n >= 1e9) return (n / 1e9).toFixed(2) + "B blocks";
    if (n >= 1e6) return (n / 1e6).toFixed(1) + "M blocks";
    return n.toLocaleString() + " blocks";
}

function renderGpuTopology() {
    const grid = document.getElementById("gpuClusterGrid");
    if (!grid) return;
    grid.innerHTML = gpuNodes.map(node => {
        const utilClass = node.util > 85 ? "crit" : node.util > 65 ? "high" : "";
        return `
            <div class="gpu-node ${node.status}" data-id="${node.id}" title="${node.region}">
                <div class="gpu-node-head">
                    <span class="gpu-id">${node.id}</span>
                    <span class="gpu-role">${node.role}</span>
                </div>
                <div class="gpu-meta">${node.type} · ${node.region.split("-")[0].toUpperCase()}</div>
                <div class="gpu-bar-track"><div class="gpu-bar-fill ${utilClass}" style="width:${node.util.toFixed(0)}%"></div></div>
                <div class="gpu-stats">
                    <span>UTIL ${node.util.toFixed(0)}%</span>
                    <span>CUDA ${node.cuda}</span>
                    <span>Q ${node.queue}</span>
                </div>
            </div>
        `;
    }).join("");
}

function renderSimQueue() {
    const list = document.getElementById("simJobList");
    if (!list) return;
    list.innerHTML = simJobs.map(job => `
        <div class="sim-job ${job.state}">
            <div class="sim-job-row">
                <span class="sim-job-name">${job.name}</span>
                <span class="sim-job-eta">${job.state === "queued" ? "QUEUED" : job.state === "complete" ? "DONE" : "ETA " + job.eta}</span>
            </div>
            <div class="sim-job-bar"><div class="sim-job-fill" style="width:${job.progress}%"></div></div>
            <div class="sim-job-meta">${job.gpus} GPU · ${job.progress.toFixed(0)}%</div>
        </div>
    `).join("");
}

function renderGlobalOpsMap() {
    const map = document.getElementById("globalOpsMap");
    if (!map) return;

    let sites = [];
    if (typeof getActiveProject === "function" && getActiveProject() && getActiveProject().sites) {
        sites = getActiveProject().sites;
    }
    if (!sites.length) {
        sites = [{ name: "Project site", x: 50, y: 50, active: true }];
    }

    map.innerHTML = sites.map(s => `
        <span class="ops-site ${s.active ? "live" : "standby"}" style="left:${s.x}%;top:${s.y}%"
              title="${s.name}">${s.active ? "●" : "○"}</span>
    `).join("");
}

function pushLiveEvent(message, type = "info") {
    const ts = new Date().toLocaleTimeString("en-GB", { hour12: false });
    liveEvents.unshift({ ts, message, type });
    if (liveEvents.length > 40) liveEvents.pop();
    renderLiveFeed();
}

function renderLiveFeed() {
    const feed = document.getElementById("liveOpsFeed");
    if (!feed) return;
    feed.innerHTML = liveEvents.slice(0, 12).map(e => `
        <div class="ops-event ${e.type}">
            <span class="ops-ts">${e.ts}</span>
            <span class="ops-msg">${e.message}</span>
        </div>
    `).join("");
}

function simulateInfrastructureEvents() {
    const roll = Math.random();
    if (roll < 0.15) {
        const node = gpuNodes[Math.floor(Math.random() * gpuNodes.length)];
        node.status = "failed";
        node.util = 0;
        pushLiveEvent(`ALERT: ${node.id} heartbeat lost — rerouting CUDA workloads`, "warn");
        showAlertBanner(`CRITICAL: ${node.id} offline — CUDA failover engaged`, "error");
        setModuleState(node.role === "kriging" ? "blockmodel" : "simulation", "failed");
        setTimeout(() => {
            node.status = "recovering";
            pushLiveEvent(`${node.id} entering recovery — checkpoint restore`, "info");
            setModuleState(node.role === "kriging" ? "blockmodel" : "simulation", "recovering");
        }, 3500);
        setTimeout(() => {
            node.status = "online";
            node.util = 25 + Math.random() * 30;
            pushLiveEvent(`${node.id} restored — mesh sync complete`, "success");
            setModuleState(node.role === "kriging" ? "blockmodel" : "simulation", "idle");
            scaleMetrics.gpuNodesOnline = gpuNodes.filter(n => n.status === "online").length;
        }, 7000);
    } else if (roll < 0.35) {
        pushLiveEvent(`Drillhole batch +${120 + Math.floor(Math.random() * 400)} collars ingested`, "info");
        setModuleState("geology", "loading");
        setTimeout(() => setModuleState("geology", "computing"), 800);
        setTimeout(() => setModuleState("geology", "idle"), 3200);
    } else if (roll < 0.55) {
        pushLiveEvent("AI confidence dip 0.82 — human review queued", "warn");
    } else {
        pushLiveEvent(`Telemetry burst: ${(2 + Math.random() * 5).toFixed(1)}k sensor samples/s`, "info");
    }
    scaleMetrics.gpuNodesOnline = gpuNodes.filter(n => n.status === "online").length;
}

function runOrchestrationPipeline(workflowLabel, targetModule, onComplete, options) {
    if (pipelineActive) {
        pushLiveEvent("Orchestrator busy — queueing next workflow", "warn");
        return;
    }
    pipelineActive = true;
    pipelineStageIndex = -1;
    const opts = options || {};

    const strip = document.getElementById("pipelineStrip");
    if (strip) {
        strip.classList.add("active");
        strip.classList.remove("idle-pulse");
    }

    pushLiveEvent(`Workflow: ${workflowLabel}`, "info");
    setModuleState(targetModule, "ai-inference");
    updateAIAgentPanel("AI Agent activated — reasoning", [
        { text: "Parse user / menu intent", done: true },
        { text: "Select compute partition", done: false }
    ]);
    appendAITerminal(`Orchestrator: ${workflowLabel}`, "info-msg");

    const stages = PIPELINE_STAGES;
    let i = 0;

    function onStageHook(stage, index) {
        if (opts.onStage) opts.onStage(stage, index);
        if (typeof handleDefaultStageEffects === "function") {
            handleDefaultStageEffects(stage, index, targetModule, workflowLabel);
        }
    }

    function advance() {
        if (i > 0 && i <= stages.length) {
            const prev = document.getElementById(`pipe-${stages[i - 1].id}`);
            if (prev) {
                prev.classList.remove("active");
                prev.classList.add("done");
            }
        }
        if (i < stages.length) {
            pipelineStageIndex = i;
            const stage = stages[i];
            const cur = document.getElementById(`pipe-${stage.id}`);
            if (cur) cur.classList.add("active");
            const label = document.getElementById("pipelineStatusLabel");
            if (label) label.textContent = stage.label + "…";
            onStageHook(stage, i);

            if (i === 1) setModuleState(targetModule, "ai-inference");
            if (i === 2) setModuleState(targetModule, "distributed");
            if (i === 3) setModuleState(targetModule, "computing");
            if (i === 4) {
                digitalTwinSyncActive = true;
                setModuleState(targetModule, "syncing");
            }
            if (i === 5) {
                digitalTwinSyncActive = true;
            }

            i++;
            setTimeout(advance, opts.stepMs || 580);
        } else {
            finishPipeline(targetModule, onComplete, strip);
        }
    }
    resetPipelineUI();
    advance();
}

function handleDefaultStageEffects(stage, index, targetModule, workflowLabel) {
    const tasks = [
        { text: "Data source validated", done: index > 0 },
        { text: "AI task assignment", done: index > 1 },
        { text: "GPU queue scheduled", done: index > 2 },
        { text: "Optimization running", done: index > 3 },
        { text: "Viewport refresh", done: index > 4 },
        { text: "Twin sync", done: index > 5 }
    ];
    updateAIAgentPanel(`Stage: ${stage.label}`, tasks);
    appendAITerminal(`>> ${stage.label}`, "system-msg");
}

function resetPipelineUI() {
    PIPELINE_STAGES.forEach(s => {
        const el = document.getElementById(`pipe-${s.id}`);
        if (el) el.className = "pipe-stage";
    });
}

function finishPipeline(targetModule, onComplete, strip) {
    const label = document.getElementById("pipelineStatusLabel");
    if (label) label.textContent = "Digital twin synced";
    updateAIAgentPanel("Agent idle — ready to orchestrate", [
        { text: "Workflow complete", done: true }
    ]);
    setTimeout(() => {
        if (strip) {
            strip.classList.remove("active");
            strip.classList.add("idle-pulse");
        }
        pipelineActive = false;
        pipelineStageIndex = -1;
        digitalTwinSyncActive = false;
        ["geometry", "geology", "blockmodel", "engineering", "simulation", "economics"].forEach(m => {
            if (moduleStates[m] !== "failed" && moduleStates[m] !== "recovering") {
                setModuleState(m, "idle");
            }
        });
        if (label) label.textContent = "Orchestrator idle — awaiting command";
        resetPipelineUI();
        pushLiveEvent("Pipeline complete — all engines nominal", "success");
        showAlertBanner("Digital twin synchronized — all engines nominal", "success");
        if (onComplete) onComplete();
    }, 900);
}

function triggerStopeOptimization() {
    triggerStopeOptimizationFull();
}

function triggerStopeOptimizationFull() {
    runOrchestrationPipeline("Stope Optimization", "engineering", () => {
        loadModule("engineering");
    }, {
        onStage(stage) {
            if (stage.id === "ai") {
                appendAITerminal("AI: assigning stope shape constraints (SF>1.15)", "info-msg");
            }
            if (stage.id === "compute") {
                assignGpuSimulationQueue();
                setModuleState("engineering", "distributed");
            }
            if (stage.id === "optimize") {
                loadModule("engineering");
                setModuleState("engineering", "computing");
            }
            if (stage.id === "visualize") {
                loadModule("simulation");
                setModuleState("simulation", "computing");
                resetSimulation();
            }
            if (stage.id === "twin") {
                loadModule("economics");
                setModuleState("economics", "syncing");
                setModuleState("simulation", "syncing");
            }
        }
    });
}

function assignGpuSimulationQueue() {
    simJobs.forEach((job, i) => {
        if (job.name.indexOf("Fleet") >= 0 || job.name.indexOf("Stope") >= 0) {
            job.state = "running";
            job.progress = Math.max(job.progress, 10);
            job.gpus = 2 + (i % 2);
        }
    });
    gpuNodes.forEach(n => {
        if (n.role === "simulation") n.util = Math.min(98, n.util + 25);
    });
    renderSimQueue();
    pushLiveEvent("GPU simulation queue assigned — 4x CUDA workers", "info");
    showAlertBanner("GPU queue: Stope-OPT + Fleet-DES pinned to H100 partition", "info");
}

window.addEventListener("DOMContentLoaded", () => {
    if (document.getElementById("pipelineStrip")) {
        initOrchestration();
    }
});
