/* ==========================================================================
   NGMEP — Multi-Organization / Multi-Project Workspace (CAD-style tenancy)
   Each company maintains isolated projects, simulations, and saved state.
   ========================================================================== */

const TENANT_STORAGE_KEY = "ngmep_tenant_registry";
const ORG_PREFIX = "ngmep_org_";

/** @type {{ activeOrgId: string|null, activeProjectId: string|null }} */
let tenantSession = { activeOrgId: null, activeProjectId: null };

/** @type {object|null} Cached active project */
let activeProject = null;

/** @type {object|null} Cached active org */
let activeOrg = null;

const PROJECT_TEMPLATES = {
    blank: {
        name: "New Project",
        commodity: "Au",
        depositType: "open-pit",
        utmZone: "50S",
        gridSizeM: 25,
        sites: [{ name: "Site A", x: 50, y: 50, active: true }],
        blocksIndexed: 120000000,
        scanVolumePB: 0.12,
        cloudRegions: 1,
        gpuNodes: 4
    },
    gold_open_pit: {
        name: "Open Pit Gold",
        commodity: "Au",
        depositType: "open-pit",
        utmZone: "50S",
        gridSizeM: 25,
        sites: [
            { name: "Main Pit", x: 50, y: 50, active: true },
            { name: "North Extension", x: 30, y: 35, active: false }
        ],
        blocksIndexed: 890000000,
        scanVolumePB: 0.45,
        cloudRegions: 2,
        gpuNodes: 8
    },
    copper_underground: {
        name: "UG Copper",
        commodity: "Cu",
        depositType: "underground",
        utmZone: "19S",
        gridSizeM: 15,
        sites: [
            { name: "Decline 1", x: 45, y: 55, active: true },
            { name: "Stope Block B", x: 60, y: 48, active: true }
        ],
        blocksIndexed: 420000000,
        scanVolumePB: 0.28,
        cloudRegions: 2,
        gpuNodes: 6
    },
    iron_multi_site: {
        name: "Multi-Site Iron",
        commodity: "Fe",
        depositType: "open-pit",
        utmZone: "50S",
        gridSizeM: 50,
        sites: [
            { name: "Pit North", x: 25, y: 40, active: true },
            { name: "Pit South", x: 55, y: 65, active: true },
            { name: "Rail Loadout", x: 75, y: 45, active: true }
        ],
        blocksIndexed: 2100000000,
        scanVolumePB: 1.2,
        cloudRegions: 3,
        gpuNodes: 12
    }
};

function generateId(prefix) {
    return prefix + "_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 8);
}

function loadRegistry() {
    try {
        const raw = localStorage.getItem(TENANT_STORAGE_KEY);
        if (raw) return JSON.parse(raw);
    } catch (_) { /* ignore */ }
    return { activeOrgId: null, activeProjectId: null, orgs: [] };
}

function saveRegistry(reg) {
    localStorage.setItem(TENANT_STORAGE_KEY, JSON.stringify(reg));
}

function loadOrgData(orgId) {
    try {
        const raw = localStorage.getItem(ORG_PREFIX + orgId);
        if (raw) return JSON.parse(raw);
    } catch (_) { /* ignore */ }
    return null;
}

function saveOrgData(orgId, data) {
    localStorage.setItem(ORG_PREFIX + orgId, JSON.stringify(data));
}

function getActiveOrg() {
    return activeOrg;
}

function getActiveProject() {
    return activeProject;
}

function createOrganization(name, options) {
    const reg = loadRegistry();
    const id = generateId("org");
    const org = {
        id,
        name: name.trim() || "Untitled Company",
        license: (options && options.license) || "NGMEP-PRO",
        cloudRegion: (options && options.cloudRegion) || "ap-southeast-2",
        created: new Date().toISOString()
    };
    reg.orgs.push({ id: org.id, name: org.name });
    saveRegistry(reg);
    saveOrgData(id, { org, projects: [] });
    return org;
}

function createProject(orgId, templateKey, customName) {
    const orgData = loadOrgData(orgId);
    if (!orgData) return null;

    const tpl = PROJECT_TEMPLATES[templateKey] || PROJECT_TEMPLATES.blank;
    const project = {
        id: generateId("proj"),
        name: customName || tpl.name,
        commodity: tpl.commodity,
        depositType: tpl.depositType,
        utmZone: tpl.utmZone,
        gridSizeM: tpl.gridSizeM,
        sites: JSON.parse(JSON.stringify(tpl.sites)),
        blocksIndexed: tpl.blocksIndexed,
        scanVolumePB: tpl.scanVolumePB,
        cloudRegions: tpl.cloudRegions,
        gpuNodes: tpl.gpuNodes,
        created: new Date().toISOString(),
        modified: new Date().toISOString(),
        workspace: null
    };

    orgData.projects.push(project);
    saveOrgData(orgId, orgData);
    return project;
}

function deleteOrganization(orgId) {
    const reg = loadRegistry();
    reg.orgs = reg.orgs.filter(o => o.id !== orgId);
    if (reg.activeOrgId === orgId) {
        reg.activeOrgId = null;
        reg.activeProjectId = null;
    }
    saveRegistry(reg);
    localStorage.removeItem(ORG_PREFIX + orgId);
}

function listOrganizations() {
    return loadRegistry().orgs;
}

function listProjects(orgId) {
    const data = loadOrgData(orgId);
    return data ? data.projects : [];
}

function getDefaultWorkspaceForProject(project) {
    return {
        activeEngine: project.depositType === "underground" ? "engineering" : "geology",
        yaw: 45,
        pitch: 35,
        zoom: 1.0,
        panX: 0,
        panY: 0,
        geomMeshRes: 15,
        geologySliceOffset: 0,
        geologyShowBoreholes: true,
        blockGradeCutoff: project.commodity === "Au" ? 0.5 : project.commodity === "Cu" ? 0.8 : 1.2,
        econGoldPrice: project.commodity === "Au" ? 2000 : 1800,
        viewportMode: "module",
        menuPrefs: { compositeView: false, showTunnels: project.depositType === "underground", infraDockVisible: true }
    };
}

function applyWorkspaceState(state) {
    if (!state) return;
    if (state.yaw !== undefined) yaw = state.yaw;
    if (state.pitch !== undefined) pitch = state.pitch;
    if (state.zoom !== undefined) zoom = state.zoom;
    if (state.panX !== undefined) panX = state.panX;
    if (state.panY !== undefined) panY = state.panY;
    if (state.geomMeshRes) geomMeshRes = state.geomMeshRes;
    if (state.geologySliceOffset !== undefined) geologySliceOffset = state.geologySliceOffset;
    if (state.geologyShowBoreholes !== undefined) geologyShowBoreholes = state.geologyShowBoreholes;
    if (state.blockGradeCutoff !== undefined) blockGradeCutoff = state.blockGradeCutoff;
    if (state.econGoldPrice) econGoldPrice = state.econGoldPrice;
    if (state.menuPrefs && typeof menuPrefs !== "undefined") {
        menuPrefs = { ...menuPrefs, ...state.menuPrefs };
    }
    if (state.viewportMode) {
        viewportMode = state.viewportMode;
        if (typeof menuPrefs !== "undefined") menuPrefs.compositeView = viewportMode === "composite";
    }
    if (typeof showUndergroundTunnels !== "undefined" && state.menuPrefs) {
        showUndergroundTunnels = state.menuPrefs.showTunnels !== false;
    }
    if (typeof toggleInfraDock === "function" && state.menuPrefs) {
        toggleInfraDock(state.menuPrefs.infraDockVisible !== false);
    }
    if (typeof updateCameraHUD === "function") updateCameraHUD();
    if (typeof updateViewportHUD === "function") updateViewportHUD();
    if (typeof syncMenuCheckStates === "function") syncMenuCheckStates();
    if (state.activeEngine && typeof loadModule === "function") loadModule(state.activeEngine);
}

function captureWorkspaceState() {
    return {
        activeEngine: typeof activeEngine !== "undefined" ? activeEngine : "geometry",
        yaw, pitch, zoom, panX, panY,
        geomMeshRes,
        geologySliceOffset,
        geologyShowBoreholes,
        blockGradeCutoff,
        econGoldPrice,
        viewportMode: typeof viewportMode !== "undefined" ? viewportMode : "module",
        menuPrefs: typeof menuPrefs !== "undefined" ? { ...menuPrefs } : {}
    };
}

function saveCurrentProjectWorkspace() {
    if (!tenantSession.activeOrgId || !tenantSession.activeProjectId || !activeProject) return false;
    const orgData = loadOrgData(tenantSession.activeOrgId);
    if (!orgData) return false;

    const idx = orgData.projects.findIndex(p => p.id === tenantSession.activeProjectId);
    if (idx < 0) return false;

    orgData.projects[idx].workspace = captureWorkspaceState();
    orgData.projects[idx].modified = new Date().toISOString();
    activeProject = orgData.projects[idx];
    saveOrgData(tenantSession.activeOrgId, orgData);

    if (typeof saveWorkspaceToApi === "function") {
        saveWorkspaceToApi().catch(err => {
            if (typeof pushLiveEvent === "function") {
                pushLiveEvent("API save failed: " + err.message, "warn");
            }
        });
    }
    return true;
}

function applyProjectContext(project, org) {
    activeProject = project;
    activeOrg = org;

    if (typeof scaleMetrics !== "undefined") {
        scaleMetrics.blocksIndexed = project.blocksIndexed || 100000000;
        scaleMetrics.scanVolumePB = project.scanVolumePB || 0.1;
        scaleMetrics.activeMines = (project.sites || []).length;
        scaleMetrics.cloudRegions = project.cloudRegions || 1;
    }

    if (typeof seedGpuClusterForProject === "function") {
        seedGpuClusterForProject(project.gpuNodes || 6);
    } else if (typeof seedGpuCluster === "function") {
        seedGpuCluster();
    }

    if (typeof updateScaleHUD === "function") updateScaleHUD();
    if (typeof renderGlobalOpsMap === "function") renderGlobalOpsMap();
    if (typeof updateTenantUI === "function") updateTenantUI();
    if (typeof updateViewportProjectHUD === "function") updateViewportProjectHUD();

    const gridEl = document.querySelector("#viewportTitleHUD .active-details");
    if (gridEl && project.gridSizeM) {
        const modeEl = document.getElementById("viewportModeLabel");
        const modeTxt = modeEl ? modeEl.textContent + " | " : "";
        const ent = document.getElementById("renderedObjects");
        const entTxt = ent ? ent.textContent : "";
        /* grid line updated in updateViewportProjectHUD */
    }
}

function openProject(orgId, projectId) {
    saveCurrentProjectWorkspace();

    const orgData = loadOrgData(orgId);
    if (!orgData) return false;

    const project = orgData.projects.find(p => p.id === projectId);
    if (!project) return false;

    const reg = loadRegistry();
    reg.activeOrgId = orgId;
    reg.activeProjectId = projectId;
    saveRegistry(reg);

    tenantSession.activeOrgId = orgId;
    tenantSession.activeProjectId = projectId;

    applyProjectContext(project, orgData.org);

    const ws = project.workspace || getDefaultWorkspaceForProject(project);
    applyWorkspaceState(ws);

    if (project.depositType === "underground" && typeof showUndergroundTunnels !== "undefined") {
        showUndergroundTunnels = true;
    }

    if (typeof pushLiveEvent === "function") {
        pushLiveEvent(`Project opened: ${project.name} (${orgData.org.name})`, "success");
    }
    if (typeof showAlertBanner === "function") {
        showAlertBanner(`${orgData.org.name} — ${project.name}`, "info");
    }

    hideTenancyModal();
    return true;
}

function switchOrganization(orgId) {
    saveCurrentProjectWorkspace();
    const orgData = loadOrgData(orgId);
    if (!orgData) return;

    tenantSession.activeOrgId = orgId;
    activeOrg = orgData.org;
    updateTenantUI();

    if (!orgData.projects.length) {
        showTenancyModal("project");
        return;
    }
    openProject(orgId, orgData.projects[0].id);
}

async function initTenancy() {
    if (typeof isApiEnabled === "function" && isApiEnabled()) {
        const synced = await syncTenancyFromApi();
        if (synced) {
            hideTenancyModal();
            return;
        }
    }

    const reg = loadRegistry();

    if (reg.orgs.length === 0) {
        seedExampleOrganizations();
        return initTenancy();
    }

    tenantSession.activeOrgId = reg.activeOrgId;
    tenantSession.activeProjectId = reg.activeProjectId;

    if (!reg.activeOrgId || !reg.activeProjectId) {
        if (reg.orgs.length > 0) {
            const firstOrg = reg.orgs[0].id;
            const projects = listProjects(firstOrg);
            if (projects.length) {
                openProject(firstOrg, projects[0].id);
                return;
            }
        }
        showTenancyModal("org");
        return;
    }

    openProject(reg.activeOrgId, reg.activeProjectId);
}

function seedExampleOrganizations() {
    const demos = [
        { name: "Apex Mining Corp", template: "gold_open_pit", projectName: "Sunrise Gold OP" },
        { name: "Continental Resources", template: "iron_multi_site", projectName: "Hematite North" },
        { name: "Kopano Minerals (Pty)", template: "copper_underground", projectName: "Maseve UG Cu" }
    ];

    demos.forEach(d => {
        const org = createOrganization(d.name, { license: "NGMEP-ENTERPRISE" });
        createProject(org.id, d.template, d.projectName);
    });

    const reg = loadRegistry();
    if (reg.orgs.length) {
        const first = reg.orgs[0].id;
        const projs = listProjects(first);
        if (projs.length) {
            reg.activeOrgId = first;
            reg.activeProjectId = projs[0].id;
            saveRegistry(reg);
        }
    }
}

/* ---------- UI ---------- */

function updateTenantUI() {
    const orgSelect = document.getElementById("tenantOrgSelect");
    const projSelect = document.getElementById("tenantProjectSelect");
    const orgLabel = document.getElementById("tenantOrgLabel");
    const projLabel = document.getElementById("tenantProjectLabel");

    const orgs = listOrganizations();

    if (orgSelect) {
        orgSelect.innerHTML = orgs.map(o =>
            `<option value="${o.id}" ${o.id === tenantSession.activeOrgId ? "selected" : ""}>${escapeHtml(o.name)}</option>`
        ).join("");
    }

    if (projSelect && tenantSession.activeOrgId) {
        const projects = listProjects(tenantSession.activeOrgId);
        projSelect.innerHTML = projects.map(p =>
            `<option value="${p.id}" ${p.id === tenantSession.activeProjectId ? "selected" : ""}>${escapeHtml(p.name)}</option>`
        ).join("");
    }

    if (orgLabel && activeOrg) orgLabel.textContent = activeOrg.name;
    if (projLabel && activeProject) projLabel.textContent = activeProject.name;

    document.title = activeProject && activeOrg
        ? `${activeProject.name} — ${activeOrg.name} | NGMEP`
        : "NGMEP — Mining Engineering Platform";
}

function updateViewportProjectHUD() {
    if (!activeProject || !activeOrg) return;

    const titleEl = document.getElementById("viewportTitle");
    const badge = document.querySelector("#viewportTitleHUD .active-badge");
    const details = document.querySelector("#viewportTitleHUD .active-details");

    if (badge) {
        badge.textContent = activeOrg.name.toUpperCase().slice(0, 24);
        badge.style.color = "var(--color-cyan)";
    }

    if (details) {
        const modeEl = document.getElementById("viewportModeLabel");
        const mode = modeEl ? modeEl.textContent : "MODULE VIEW";
        details.innerHTML = `
            <span>${mode}</span> |
            <span>GRID: ${activeProject.gridSizeM}m</span> |
            <span>${activeProject.commodity} · ${activeProject.depositType}</span> |
            <span id="renderedObjects">ENTITIES: —</span>
        `;
    }

    if (titleEl && typeof getModuleFriendlyName === "function" && typeof activeEngine !== "undefined") {
        titleEl.innerText = getModuleFriendlyName(activeEngine);
    }
}

function escapeHtml(s) {
    const d = document.createElement("div");
    d.textContent = s;
    return d.innerHTML;
}

function showTenancyModal(step) {
    const modal = document.getElementById("tenancyModal");
    if (!modal) return;
    modal.classList.remove("hidden");
    modal.dataset.step = step || "org";
    renderTenancyModalContent(step || "org");
}

function hideTenancyModal() {
    const modal = document.getElementById("tenancyModal");
    if (modal) modal.classList.add("hidden");
}

function renderTenancyModalContent(step) {
    const body = document.getElementById("tenancyModalBody");
    if (!body) return;

    if (step === "org") {
        const orgs = listOrganizations();
        body.innerHTML = `
            <p class="tenancy-lead">NGMEP is licensed per <strong>organization</strong>. Each company maintains its own projects, block models, and simulations — like Surpac, Vulcan, or Deswik.</p>
            <div class="tenancy-section">
                <h4>Your organizations</h4>
                <ul class="tenancy-list" id="tenancyOrgList">
                    ${orgs.map(o => `
                        <li>
                            <button type="button" class="tenancy-pick-btn" data-org="${o.id}">
                                <span class="pick-name">${escapeHtml(o.name)}</span>
                                <span class="pick-meta">${listProjects(o.id).length} project(s)</span>
                            </button>
                        </li>
                    `).join("")}
                </ul>
            </div>
            <div class="tenancy-form">
                <h4>Create new organization</h4>
                <input type="text" id="newOrgName" placeholder="Company name" class="tenancy-input">
                <button type="button" class="tenancy-primary-btn" id="btnCreateOrg">Create organization</button>
            </div>
        `;
        body.querySelectorAll(".tenancy-pick-btn").forEach(btn => {
            btn.addEventListener("click", () => switchOrganization(btn.dataset.org));
        });
        const createBtn = document.getElementById("btnCreateOrg");
        if (createBtn) {
            createBtn.addEventListener("click", () => {
                const name = document.getElementById("newOrgName").value;
                if (!name.trim()) return;
                const org = createOrganization(name);
                showTenancyModal("project");
                tenantSession.activeOrgId = org.id;
                activeOrg = org;
                renderTenancyModalContent("project");
            });
        }
    } else if (step === "project") {
        const orgId = tenantSession.activeOrgId;
        const orgData = orgId ? loadOrgData(orgId) : null;
        const orgName = orgData ? orgData.org.name : "Organization";
        const projects = orgId ? listProjects(orgId) : [];

        body.innerHTML = `
            <p class="tenancy-lead">Select or create a <strong>project</strong> for <em>${escapeHtml(orgName)}</em>. Each project has isolated geology, designs, and simulation data.</p>
            <div class="tenancy-section">
                <h4>Projects</h4>
                <ul class="tenancy-list">
                    ${projects.map(p => `
                        <li>
                            <button type="button" class="tenancy-pick-btn" data-proj="${p.id}">
                                <span class="pick-name">${escapeHtml(p.name)}</span>
                                <span class="pick-meta">${p.commodity} · ${p.depositType} · UTM ${p.utmZone}</span>
                            </button>
                        </li>
                    `).join("") || "<li class='tenancy-empty'>No projects yet — create one below.</li>"}
                </ul>
            </div>
            <div class="tenancy-form">
                <h4>New project from template</h4>
                <input type="text" id="newProjName" placeholder="Project name" class="tenancy-input">
                <select id="newProjTemplate" class="tenancy-input">
                    <option value="blank">Blank project</option>
                    <option value="gold_open_pit">Open-pit gold</option>
                    <option value="copper_underground">Underground copper</option>
                    <option value="iron_multi_site">Multi-site iron ore</option>
                </select>
                <button type="button" class="tenancy-primary-btn" id="btnCreateProj">Create & open project</button>
            </div>
        `;
        body.querySelectorAll("[data-proj]").forEach(btn => {
            btn.addEventListener("click", () => openProject(orgId, btn.dataset.proj));
        });
        const createProj = document.getElementById("btnCreateProj");
        if (createProj) {
            createProj.addEventListener("click", () => {
                const name = document.getElementById("newProjName").value;
                const tpl = document.getElementById("newProjTemplate").value;
                const proj = createProject(orgId, tpl, name.trim() || undefined);
                if (proj) openProject(orgId, proj.id);
            });
        }
    }
}

function onTenantOrgChange(orgId) {
    if (!orgId) return;
    switchOrganization(orgId);
}

function onTenantProjectChange(projectId) {
    if (!tenantSession.activeOrgId || !projectId) return;
    openProject(tenantSession.activeOrgId, projectId);
}

function openOrganizationManager() {
    showTenancyModal("org");
}

function openProjectManager() {
    if (!tenantSession.activeOrgId) {
        showTenancyModal("org");
        return;
    }
    showTenancyModal("project");
}
