/* ==========================================================================
   NGMEP — Integrated User Manual & Documentation System
   ========================================================================== */

// Manual Tab Contents Map
const MANUAL_TABS = {
    overview: `
        <div class="manual-sec">
            <h4>System Overview</h4>
            <p><b>NGMEP (Next-Generation Mining Engineering Platform)</b> is licensed and used <b>per organization</b> — the same way Surpac, Vulcan, and Deswik serve many different mining companies. Each company creates its own <b>projects</b>; geology, block models, pit designs, and simulations are stored separately per project.</p>
            <p>Use the <b>ORG</b> and <b>PROJECT</b> selectors in the top bar to switch context, or <b>File → Switch Organization / Open Project</b> to manage tenants. <kbd>Ctrl+S</kbd> saves the active project workspace only.</p>
            <p>Within a project, use the engineering modules or the <b>AI Copilot</b> to run workflows on that company's data.</p>
        </div>
    `,
    modules: `
        <div class="manual-sec">
            <h4>Engineering Engines</h4>
            <ul>
                <li>
                    <b>📐 Geometry Kernel</b><br>
                    Loads coordinate systems and projects wireframe meshes (Digital Elevation Models). Demonstrates fundamental orthographic CAD transformations.
                </li>
                <li>
                    <b>🪵 Geological Modeling</b><br>
                    Renders stratified ground structures (Soil, Siltstone, Sandstone, Basalt) and exposes core boreholes segment logging. Visualizes orebody shells.
                </li>
                <li>
                    <b>📦 Block Model Engine</b><br>
                    Establishes 3D kriging grade cells. Voxel colors represent gold grades (Au g/t). Filter out low-grade waste rock using the parameter cutoff slider.
                </li>
                <li>
                    <b>🏗️ Mine Engineering</b><br>
                    Calculates pit design contours, structures concentric benches, cuts a spiral haul ramp path, and tags warning zones with low safety factors (SF).
                </li>
                <li>
                    <b>⚡ Simulation Engine</b><br>
                    Runs a continuous physics particle animation loop. Loader excavator loads ore onto a truck fleet hauling it up the pit road to the crusher plant.
                </li>
                <li>
                    <b>📈 Economic Engine</b><br>
                    Runs discounted cash flow (DCF) models based on live fuel and metal price indexes. Plots NPV sensitivity curves and production bar charts.
                </li>
            </ul>
        </div>
    `,
    copilot: `
        <div class="manual-sec">
            <h4>AI Copilot Directory</h4>
            <p>The AI terminal parses natural language commands to automatically configure layouts, update parameter states, and trigger camera actions.</p>
            <table class="cmd-table">
                <thead>
                    <tr><th>Command Phrase</th><th>Action Triggers</th></tr>
                </thead>
                <tbody>
                    <tr><td class="cmd-name">geometry res 25</td><td>Loads geometry kernel at 25x25 grid size</td></tr>
                    <tr><td class="cmd-name">geology section</td><td>Loads geology and slices cutting plane</td></tr>
                    <tr><td class="cmd-name">cutoff 2.2</td><td>Filters block model for grades >= 2.2 g/t</td></tr>
                    <tr><td class="cmd-name">simulate 12 trucks</td><td>Spawns a fleet of 12 hauling trucks</td></tr>
                    <tr><td class="cmd-name">gold price 2400</td><td>Solves NPV formulas at $2400/oz gold</td></tr>
                    <tr><td class="cmd-name">help / manual</td><td>Opens this documentation panel</td></tr>
                </tbody>
            </table>
            <p class="text-muted" style="margin-top: 8px;">Tips: Click on any of the quick-tag chips below the terminal to pre-fill commands instantly.</p>
        </div>
    `,
    controls: `
        <div class="manual-sec">
            <h4>CAD Workspace Operations</h4>
            <p>Navigate the pseudo-3D digital twin viewport with standard CAD mouse mappings:</p>
            <ul>
                <li><b>Left-Click + Drag:</b> Orbit/Rotate camera yaw & pitch around center.</li>
                <li><b>Right-Click + Drag:</b> Pan camera center coordinates (or use <kbd>Shift</kbd> + Left-Click).</li>
                <li><b>Scroll Wheel:</b> Zoom scale levels in/out.</li>
            </ul>
            <h4>Hotkeys List</h4>
            <ul>
                <li><kbd>F1</kbd> : Toggle Manual panel open/closed</li>
                <li><kbd>Esc</kbd> : Close open modal overlays</li>
                <li><kbd>1</kbd> - <kbd>6</kbd> : Switch between modules 1 to 6 instantly</li>
            </ul>
        </div>
    `
};

let currentTab = "overview";

/**
 * Toggles the Manual visibility state
 */
function toggleManual() {
    let panel = document.getElementById("manualPanel");
    let triggerBtn = document.getElementById("manualTriggerBtn");
    
    if (panel.classList.contains("closed")) {
        panel.classList.remove("closed");
        if (triggerBtn) triggerBtn.style.display = "none";
        // Force refresh tab
        switchManualTab(currentTab);
    } else {
        panel.classList.add("closed");
        // Only show trigger button if manual is not docked (responsive/hidden states)
        if (triggerBtn && (window.innerWidth <= 900 || panel.classList.contains("floating"))) {
            triggerBtn.style.display = "block";
        } else if (triggerBtn && panel.classList.contains("docked")) {
            // Keep hidden if docked but hidden
            triggerBtn.style.display = "block";
        } else if (triggerBtn) {
            triggerBtn.style.display = "block";
        }
    }
}

/**
 * Toggles between right docked sidebar and floating window
 */
function toggleDock() {
    let panel = document.getElementById("manualPanel");
    let dockBtn = document.getElementById("manualDockBtn");
    let triggerBtn = document.getElementById("manualTriggerBtn");

    if (panel.classList.contains("docked")) {
        panel.classList.remove("docked");
        panel.classList.add("floating");
        dockBtn.innerText = "🔒 Dock";
        if (triggerBtn) triggerBtn.style.display = "none";
    } else {
        panel.classList.remove("floating");
        panel.classList.add("docked");
        dockBtn.innerText = "🔓 Float";
        if (triggerBtn) triggerBtn.style.display = "none";
    }
}

/**
 * Changes active tab and loads content
 */
function switchManualTab(tabId) {
    currentTab = tabId;
    
    // Manage active tab button style
    let buttons = document.querySelectorAll(".manual-tabs .tab-btn");
    buttons.forEach(btn => {
        btn.classList.remove("active");
        if (btn.getAttribute("onclick").includes(tabId)) {
            btn.classList.add("active");
        }
    });

    // Load content
    let contentContainer = document.getElementById("manualContent");
    if (contentContainer) {
        contentContainer.innerHTML = MANUAL_TABS[tabId] || "";
    }

    // Reset search filter input
    let searchInput = document.getElementById("manualSearch");
    if (searchInput) searchInput.value = "";
}

/**
 * Search keyword filter
 */
function filterManual() {
    let query = document.getElementById("manualSearch").value.toLowerCase();
    let contentContainer = document.getElementById("manualContent");
    if (!contentContainer) return;

    // We search through lists, paragraphs, and tables in the current active tab
    let items = contentContainer.querySelectorAll("p, li, tr");
    
    items.forEach(item => {
        let text = item.innerText.toLowerCase();
        if (text.includes(query)) {
            item.style.display = "";
            // Highlight query
            item.style.opacity = "1";
        } else {
            item.style.display = "none";
        }
    });
}