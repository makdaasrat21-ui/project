/* ==========================================================================
   NGMEP — Core Digital Twin Rendering Engine
   ========================================================================== */

// Global Projection State
let yaw = 45;       // Angle in degrees around Z-axis
let pitch = 35;     // Angle in degrees from horizontal
let zoom = 1.0;     // Scale multiplier
let panX = 0;       // X translation offset
let panY = 0;       // Y translation offset

// Mouse Dragging States
let isDragging = false;
let dragMode = "rotate"; // "rotate" or "pan"
let lastMouseX = 0;
let lastMouseY = 0;

// Active engine states
let activeEngine = "geometry";
let canvasEl = null;
let ctxEl = null;
let animationFrameId = null;
let entityCount = 0;

// Simulation States
let simTime = 0;
let simTrucks = [];
let simLoader = { angle: 0, state: "idle", timer: 0 };
let simParticles = [];

// Economic Parameters (linked from UI)
let econGoldPrice = 2000;
let econMiningCost = 3.50;
let econProcessingCost = 15.00;

// Block Model Cutoff (linked from UI)
let blockGradeCutoff = 0.5;

// Geological Strata Options
let geologyShowBoreholes = true;
let geologySliceOffset = 0;

// Geometry Mesh Resolution
let geomMeshRes = 15;

// Target Frame Rate Telemetry
let lastFrameTime = performance.now();
let fpsCounter = 60.0;
let cpuMockLoad = 4.2;

// Digital twin orchestration overlay
let digitalTwinSyncActive = false;
let viewportMode = "module"; // "module" | "composite"
let showUndergroundTunnels = true;
let twinTelemetry = { slope: 1.14, vent: 842, prod: 42.8, fleet: "LIVE" };

/* ==========================================================================
   CAMERA & COORDINATE PROJECTION
   ========================================================================== */

/**
 * Projects a 3D coordinate (x, y, z) into 2D screen space using orthographic projection.
 * Yaw and Pitch rotate the coordinate system, and zoom/pan scale and shift it.
 */
function project(x, y, z, width, height) {
    let radYaw = (yaw * Math.PI) / 180;
    let radPitch = (pitch * Math.PI) / 180;

    // Rotate around Z axis (Yaw)
    let rx = x * Math.cos(radYaw) - y * Math.sin(radYaw);
    let ry = x * Math.sin(radYaw) + y * Math.cos(radYaw);
    let rz = z;

    // Rotate around X axis (Pitch)
    let finalX = rx;
    let finalY = ry * Math.cos(radPitch) - rz * Math.sin(radPitch);
    let finalZ = ry * Math.sin(radPitch) + rz * Math.cos(radPitch); // Z coordinate represents depth

    // Apply scale (zoom) and translation (pan + center)
    let screenX = width / 2 + (finalX * zoom) + panX;
    let screenY = height / 2 + (finalY * zoom) + panY;

    return { x: screenX, y: screenY, depth: finalZ };
}

/* ==========================================================================
   INITIALIZATION & EVENT BINDINGS
   ========================================================================== */

function initEngine(canvas) {
    canvasEl = canvas;
    ctxEl = canvas.getContext("2d");

    // Handle Resize
    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);

    // Bind Mouse Events for CAD interaction
    canvas.addEventListener("mousedown", handleMouseDown);
    canvas.addEventListener("mousemove", handleMouseMove);
    canvas.addEventListener("mouseup", handleMouseUp);
    canvas.addEventListener("mouseleave", handleMouseUp);
    canvas.addEventListener("contextmenu", e => e.preventDefault()); // Stop right click menu
    canvas.addEventListener("wheel", handleMouseWheel, { passive: false });

    // Initialize Simulation Entities
    resetSimulation();

    // Set initial camera HUD metrics
    updateCameraHUD();

    // Start Rendering Loop
    if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
    }
    renderLoop();
}

function resizeCanvas() {
    if (canvasEl) {
        canvasEl.width = canvasEl.parentElement.clientWidth;
        canvasEl.height = canvasEl.parentElement.clientHeight;
    }
}

/* ==========================================================================
   MOUSE & WHEEL CAD INPUT INTERACTION
   ========================================================================== */

function handleMouseDown(e) {
    isDragging = true;
    lastMouseX = e.clientX;
    lastMouseY = e.clientY;
    
    // Right click or Shift + Left click is PAN
    if (e.button === 2 || e.button === 1 || e.shiftKey) {
        dragMode = "pan";
    } else {
        dragMode = "rotate";
    }
}

function handleMouseMove(e) {
    if (!isDragging) return;

    let dx = e.clientX - lastMouseX;
    let dy = e.clientY - lastMouseY;

    lastMouseX = e.clientX;
    lastMouseY = e.clientY;

    if (dragMode === "rotate") {
        yaw = (yaw - dx * 0.5) % 360;
        pitch = Math.max(-85, Math.min(85, pitch - dy * 0.5));
    } else if (dragMode === "pan") {
        panX += dx;
        panY += dy;
    }

    updateCameraHUD();
}

function handleMouseUp() {
    isDragging = false;
}

function handleMouseWheel(e) {
    e.preventDefault();
    let zoomFactor = e.deltaY < 0 ? 1.1 : 0.9;
    zoom = Math.max(0.1, Math.min(20.0, zoom * zoomFactor));
    updateCameraHUD();
}

// GUI HUD Trigger Handlers
function triggerResetView() {
    yaw = 45;
    pitch = 35;
    zoom = 1.0;
    panX = 0;
    panY = 0;
    updateCameraHUD();
}

function triggerZoom(factor) {
    zoom = Math.max(0.1, Math.min(20.0, zoom * factor));
    updateCameraHUD();
}

function triggerViewMode(mode) {
    if (mode === "top") {
        yaw = 0;
        pitch = 90;
    } else if (mode === "iso") {
        yaw = 45;
        pitch = 35;
    }
    updateCameraHUD();
}

function updateCameraHUD() {
    let stats = document.getElementById("cameraStats");
    if (stats) {
        stats.innerText = `YAW: ${Math.round(yaw)}° | PITCH: ${Math.round(pitch)}° | ZOOM: ${zoom.toFixed(1)}x`;
    }
    // Rotate visual gizmo
    let compass = document.getElementById("gizmoCompass");
    if (compass) {
        compass.style.transform = `rotate(${-yaw}deg)`;
    }
}

/* ==========================================================================
   CORE RENDER LOOP
   ========================================================================== */

function renderLoop() {
    animationFrameId = requestAnimationFrame(renderLoop);

    let now = performance.now();
    let delta = now - lastFrameTime;
    lastFrameTime = now;
    simTime += delta * 0.05;
    
    // Smooth telemetry updates
    fpsCounter = 0.95 * fpsCounter + 0.05 * (1000 / delta);
    cpuMockLoad = 0.95 * cpuMockLoad + 0.05 * (3.0 + Math.random() * 2);
    updateLiveTwinTelemetry(delta);

    // Clear Screen
    let w = canvasEl.width;
    let h = canvasEl.height;
    ctxEl.clearRect(0, 0, w, h);

    // Draw Grid Background for Viewport CAD feeling
    drawViewportGrid(w, h);

    // Render Modules
    entityCount = 0;
    if (viewportMode === "composite") {
        renderCompositeFullScene(w, h);
    } else if (activeEngine === "geometry") {
        renderGeometry(w, h);
    } else if (activeEngine === "geology") {
        renderGeology(w, h);
    } else if (activeEngine === "blockmodel") {
        renderBlockModel(w, h);
    } else if (activeEngine === "engineering") {
        renderMineEngineering(w, h);
    } else if (activeEngine === "simulation") {
        renderSimulation(w, h);
    } else if (activeEngine === "economics") {
        renderEconomics(w, h);
    }

    // Digital twin composite overlay during orchestration sync
    if (digitalTwinSyncActive && viewportMode !== "composite") {
        renderDigitalTwinComposite(w, h);
    }

    // Draw active coordinates overlay
    drawCrosshairs(w, h);

    // Update active entity HUD
    let entitiesEl = document.getElementById("renderedObjects");
    if (entitiesEl) {
        entitiesEl.innerText = `ENTITIES: ${entityCount}`;
    }
}

function drawViewportGrid(w, h) {
    ctxEl.strokeStyle = "#111420";
    ctxEl.lineWidth = 1;
    let step = 40;
    
    // Grid Lines
    for (let x = 0; x < w; x += step) {
        ctxEl.beginPath();
        ctxEl.moveTo(x, 0);
        ctxEl.lineTo(x, h);
        ctxEl.stroke();
    }
    for (let y = 0; y < h; y += step) {
        ctxEl.beginPath();
        ctxEl.moveTo(0, y);
        ctxEl.lineTo(w, y);
        ctxEl.stroke();
    }

    // Outer framing boundary
    ctxEl.strokeStyle = "#1e293b";
    ctxEl.strokeRect(1, 1, w - 2, h - 2);
}

function drawCrosshairs(w, h) {
    // Draw viewport crosshair at center
    ctxEl.strokeStyle = "rgba(6, 182, 212, 0.2)";
    ctxEl.lineWidth = 1;
    ctxEl.beginPath();
    ctxEl.moveTo(w / 2 - 20, h / 2);
    ctxEl.lineTo(w / 2 + 20, h / 2);
    ctxEl.moveTo(w / 2, h / 2 - 20);
    ctxEl.lineTo(w / 2, h / 2 + 20);
    ctxEl.stroke();

    // Corner diagnostic markers
    ctxEl.fillStyle = "rgba(6, 182, 212, 0.4)";
    ctxEl.font = "9px 'JetBrains Mono', monospace";
    ctxEl.fillText("SYS_REF: WGS84 / UTM ZONE 50S", 16, h - 16);
    ctxEl.fillText("CAMERA LOCK: LOCAL CENTER", w - 160, h - 16);
}

/* ==========================================================================
   MODULE 1: GEOMETRY KERNEL
   ========================================================================== */

function renderGeometry(w, h) {
    // Draw 3D Base Reference Grid
    let gridSize = 160;
    let gridCount = 6;
    ctxEl.lineWidth = 1;

    for (let i = -gridCount; i <= gridCount; i++) {
        let pStartVal1 = project(i * (gridSize/gridCount), -gridSize, 0, w, h);
        let pEndVal1 = project(i * (gridSize/gridCount), gridSize, 0, w, h);
        ctxEl.strokeStyle = (i === 0) ? "rgba(239, 68, 68, 0.4)" : "#1e293b"; // red X axis shadow
        ctxEl.beginPath();
        ctxEl.moveTo(pStartVal1.x, pStartVal1.y);
        ctxEl.lineTo(pEndVal1.x, pEndVal1.y);
        ctxEl.stroke();
        entityCount++;

        let pStartVal2 = project(-gridSize, i * (gridSize/gridCount), 0, w, h);
        let pEndVal2 = project(gridSize, i * (gridSize/gridCount), 0, w, h);
        ctxEl.strokeStyle = (i === 0) ? "rgba(16, 185, 129, 0.4)" : "#1e293b"; // green Y axis shadow
        ctxEl.beginPath();
        ctxEl.moveTo(pStartVal2.x, pStartVal2.y);
        ctxEl.lineTo(pEndVal2.x, pEndVal2.y);
        ctxEl.stroke();
        entityCount++;
    }

    // Draw 3D Coordinate Axis Gizmo at origin
    let axisLen = 100;
    let origin = project(0, 0, 0, w, h);
    let xAxis = project(axisLen, 0, 0, w, h);
    let yAxis = project(0, axisLen, 0, w, h);
    let zAxis = project(0, 0, axisLen, w, h);

    // X Axis (Red)
    ctxEl.strokeStyle = varColor("red");
    ctxEl.lineWidth = 2.5;
    ctxEl.beginPath();
    ctxEl.moveTo(origin.x, origin.y);
    ctxEl.lineTo(xAxis.x, xAxis.y);
    ctxEl.stroke();
    ctxEl.fillStyle = varColor("red");
    ctxEl.font = "bold 10px 'JetBrains Mono'";
    ctxEl.fillText("+X (EAST)", xAxis.x + 5, xAxis.y + 3);

    // Y Axis (Green)
    ctxEl.strokeStyle = varColor("green");
    ctxEl.beginPath();
    ctxEl.moveTo(origin.x, origin.y);
    ctxEl.lineTo(yAxis.x, yAxis.y);
    ctxEl.stroke();
    ctxEl.fillStyle = varColor("green");
    ctxEl.fillText("+Y (NORTH)", yAxis.x + 5, yAxis.y + 3);

    // Z Axis (Blue)
    ctxEl.strokeStyle = varColor("blue");
    ctxEl.beginPath();
    ctxEl.moveTo(origin.x, origin.y);
    ctxEl.lineTo(zAxis.x, zAxis.y);
    ctxEl.stroke();
    ctxEl.fillStyle = varColor("blue");
    ctxEl.fillText("+Z (ELEVATION)", zAxis.x + 5, zAxis.y - 5);
    entityCount += 3;

    // Generate and render 3D surface mesh (Digital Elevation Model mesh)
    let res = geomMeshRes;
    let size = 200;
    let step = size / res;
    ctxEl.lineWidth = 1;
    ctxEl.strokeStyle = "rgba(6, 182, 212, 0.4)";

    // Precalculate all projected grid points
    let points = [];
    for (let i = 0; i <= res; i++) {
        points[i] = [];
        for (let j = 0; j <= res; j++) {
            let x = -size/2 + i * step;
            let y = -size/2 + j * step;
            
            // Calculate a wave/terrain profile: Z elevation
            let d = Math.sqrt(x*x + y*y);
            let z = Math.sin(d / 25) * 20 + Math.cos(x / 15) * 10;
            
            points[i][j] = project(x, y, z, w, h);
            entityCount++;
        }
    }

    // Filled terrain surface (triangulated DEM)
    for (let i = 0; i < res; i++) {
        for (let j = 0; j < res; j++) {
            let p00 = points[i][j];
            let p10 = points[i + 1][j];
            let p01 = points[i][j + 1];
            let avgZ = (p00.depth + p10.depth + p01.depth) / 3;
            let alpha = 0.08 + Math.max(0, (avgZ + 30) / 80) * 0.12;
            ctxEl.fillStyle = `rgba(6, 182, 212, ${alpha})`;
            ctxEl.beginPath();
            ctxEl.moveTo(p00.x, p00.y);
            ctxEl.lineTo(p10.x, p10.y);
            ctxEl.lineTo(p01.x, p01.y);
            ctxEl.closePath();
            ctxEl.fill();
        }
    }

    // Render mesh lines
    for (let i = 0; i <= res; i++) {
        for (let j = 0; j <= res; j++) {
            if (i < res) {
                ctxEl.beginPath();
                ctxEl.moveTo(points[i][j].x, points[i][j].y);
                ctxEl.lineTo(points[i+1][j].x, points[i+1][j].y);
                ctxEl.stroke();
            }
            if (j < res) {
                ctxEl.beginPath();
                ctxEl.moveTo(points[i][j].x, points[i][j].y);
                ctxEl.lineTo(points[i][j+1].x, points[i][j+1].y);
                ctxEl.stroke();
            }
            ctxEl.fillStyle = "rgba(6, 182, 212, 0.8)";
            ctxEl.fillRect(points[i][j].x - 1, points[i][j].y - 1, 2, 2);
        }
    }
}

/* ==========================================================================
   MODULE 2: GEOLOGICAL MODEL ENGINE
   ========================================================================== */

function renderGeology(w, h) {
    let size = 160;
    let layers = [
        { name: "Topsoil Overlay", minZ: 40, maxZ: 60, fill: "rgba(100, 116, 139, 0.75)", stroke: "#94a3b8" },
        { name: "Siltstone Formation", minZ: 10, maxZ: 40, fill: "rgba(180, 83, 9, 0.7)", stroke: "#d97706" },
        { name: "Sandstone Stratum", minZ: -20, maxZ: 10, fill: "rgba(30, 58, 138, 0.65)", stroke: "#2563eb" },
        { name: "Weathered Basalt", minZ: -60, maxZ: -20, fill: "rgba(6, 95, 70, 0.7)", stroke: "#059669" }
    ];

    // Core Drillhole cylinders
    let boreholes = [
        { x: -80, y: -40, name: "BH_001A" },
        { x: 20, y: -60, name: "BH_002" },
        { x: 80, y: 40, name: "BH_003_OB" },
        { x: -40, y: 60, name: "BH_004" }
    ];

    // Orebody boundary ellipse (embedded gold zone)
    let orebody = { cx: 10, cy: -10, cz: -15, rx: 70, ry: 40, rz: 30 };

    // 1. Draw Geological strata slices (Block section cuts)
    // We render the geological block by building vertical sections
    let slices = 12;
    for (let s = 0; s < slices; s++) {
        let y = -size + (s * (2 * size / slices)) + geologySliceOffset;
        if (y < -size || y > size) continue;

        layers.forEach(layer => {
            // Draw cross sectional strip at plane Y
            let p1 = project(-size, y, layer.minZ, w, h);
            let p2 = project(size, y, layer.minZ, w, h);
            let p3 = project(size, y, layer.maxZ, w, h);
            let p4 = project(-size, y, layer.maxZ, w, h);

            ctxEl.fillStyle = layer.fill;
            ctxEl.strokeStyle = layer.stroke;
            ctxEl.lineWidth = 0.5;

            ctxEl.beginPath();
            ctxEl.moveTo(p1.x, p1.y);
            ctxEl.lineTo(p2.x, p2.y);
            ctxEl.lineTo(p3.x, p3.y);
            ctxEl.lineTo(p4.x, p4.y);
            ctxEl.closePath();
            ctxEl.fill();
            ctxEl.stroke();
            entityCount++;
        });
    }

    // 2. Draw Orebody wireframe volume
    ctxEl.strokeStyle = varColor("pink");
    ctxEl.lineWidth = 1.5;
    let oreRings = 8;
    for (let r = 0; r < oreRings; r++) {
        let zAng = (r / oreRings) * Math.PI;
        let zOffset = Math.cos(zAng) * orebody.rz;
        let rScale = Math.sin(zAng); // Ring radius scale

        ctxEl.beginPath();
        let ringSteps = 16;
        for (let step = 0; step <= ringSteps; step++) {
            let angle = (step / ringSteps) * Math.PI * 2;
            let ox = orebody.cx + Math.cos(angle) * orebody.rx * rScale;
            let oy = orebody.cy + Math.sin(angle) * orebody.ry * rScale;
            let oz = orebody.cz + zOffset;
            let projPt = project(ox, oy, oz, w, h);
            
            if (step === 0) ctxEl.moveTo(projPt.x, projPt.y);
            else ctxEl.lineTo(projPt.x, projPt.y);
        }
        ctxEl.stroke();
        entityCount++;
    }
    
    // Label Orebody
    let centerProj = project(orebody.cx, orebody.cy, orebody.cz, w, h);
    ctxEl.fillStyle = varColor("pink");
    ctxEl.font = "bold 9px 'JetBrains Mono'";
    ctxEl.fillText("ESTIMATED OREBODY SHELL", centerProj.x - 65, centerProj.y);

    // 3. Draw Drillholes / Boreholes (if toggled)
    if (geologyShowBoreholes) {
        boreholes.forEach(bh => {
            let topProj = project(bh.x, bh.y, 60, w, h);
            let bottomProj = project(bh.x, bh.y, -70, w, h);
            
            // Outer casing line
            ctxEl.strokeStyle = "#e2e8f0";
            ctxEl.lineWidth = 2.0;
            ctxEl.beginPath();
            ctxEl.moveTo(topProj.x, topProj.y);
            ctxEl.lineTo(bottomProj.x, bottomProj.y);
            ctxEl.stroke();

            // Segment colored core samples
            layers.forEach(layer => {
                let layerTop = project(bh.x, bh.y, layer.maxZ, w, h);
                let layerBottom = project(bh.x, bh.y, layer.minZ, w, h);
                
                ctxEl.strokeStyle = layer.stroke;
                ctxEl.lineWidth = 3.5;
                ctxEl.beginPath();
                ctxEl.moveTo(layerTop.x, layerTop.y);
                ctxEl.lineTo(layerBottom.x, layerBottom.y);
                ctxEl.stroke();
                entityCount++;
            });

            // Drillhole labels
            ctxEl.fillStyle = "#ffffff";
            ctxEl.font = "9px 'JetBrains Mono'";
            ctxEl.fillText(bh.name, topProj.x - 20, topProj.y - 8);
            
            // Tiny collar pad
            ctxEl.fillStyle = "#64748b";
            ctxEl.fillRect(topProj.x - 3, topProj.y - 1, 6, 2);
        });
    }
}

/* ==========================================================================
   MODULE 3: BLOCK MODEL ESTIMATION ENGINE
   ========================================================================== */

function renderBlockModel(w, h) {
    // We generate a static/semi-static grid of blocks
    // Voxel data structured in 3D grid
    let step = 20;
    let size = 5; // grid counts: 5x5x5 = 125 blocks (for canvas frame rate safety)
    let blocks = [];

    // Define grade distributions using mathematical noise
    for (let x = -size; x <= size; x++) {
        for (let y = -size; y <= size; y++) {
            for (let z = -3; z <= 2; z++) {
                let bx = x * step;
                let by = y * step;
                let bz = z * step;

                // Gold grade function (distance from centroid center)
                let dist = Math.sqrt(bx*bx + by*by + bz*bz);
                let grade = Math.max(0, 5.0 - (dist / 16.0) + Math.sin(bx/10)*0.5 + Math.cos(bz/8)*0.4);

                blocks.push({ x: bx, y: by, z: bz, grade: grade });
            }
        }
    }

    // Filter by grade cutoff
    let filteredBlocks = blocks.filter(b => b.grade >= blockGradeCutoff);

    // Calculate projected coordinates and cache depth for correct 3D overlapping
    filteredBlocks.forEach(b => {
        let proj = project(b.x, b.y, b.z, w, h);
        b.px = proj.x;
        b.py = proj.y;
        b.depth = proj.depth;
    });

    // Depth Sorting: back-to-front (lowest depth/Z drawn first)
    filteredBlocks.sort((a, b) => a.depth - b.depth);

    // Draw blocks as 3D cubes
    let cubeSize = step * 0.9; // slight spacing gap to give CAD look
    filteredBlocks.forEach(b => {
        let fill = getGradeColor(b.grade);
        drawVoxelCube(ctxEl, b.x, b.y, b.z, cubeSize, fill, w, h);
        entityCount++;
    });

    // Draw color grade legend overlay
    drawBlockModelLegend(w, h);
}

/**
 * Helper to draw a shaded 3D cube
 */
function drawVoxelCube(ctx, cx, cy, cz, s, color, w, h) {
    let hs = s / 2;
    // Calculate projected coordinates of the cube vertices
    let p0 = project(cx - hs, cy - hs, cz - hs, w, h);
    let p1 = project(cx + hs, cy - hs, cz - hs, w, h);
    let p2 = project(cx + hs, cy + hs, cz - hs, w, h);
    let p3 = project(cx - hs, cy + hs, cz - hs, w, h);
    let p4 = project(cx - hs, cy - hs, cz + hs, w, h);
    let p5 = project(cx + hs, cy - hs, cz + hs, w, h);
    let p6 = project(cx + hs, cy + hs, cz + hs, w, h);
    let p7 = project(cx - hs, cy + hs, cz + hs, w, h);

    // Draw cube faces (with shading layers)
    // Draw Top Face: p4, p5, p6, p7
    drawPolygon(ctx, [p4, p5, p6, p7], color, "rgba(0,0,0,0.05)");

    // Draw Left/Front Face: p0, p3, p7, p4
    drawPolygon(ctx, [p0, p3, p7, p4], color, "rgba(0,0,0,0.25)");

    // Draw Right/Front Face: p1, p2, p6, p5
    drawPolygon(ctx, [p1, p2, p6, p5], color, "rgba(0,0,0,0.4)");
}

function drawPolygon(ctx, pts, fill, shadowOverlay) {
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (let i = 1; i < pts.length; i++) {
        ctx.lineTo(pts[i].x, pts[i].y);
    }
    ctx.closePath();
    
    // Fill Base Color
    ctx.fillStyle = fill;
    ctx.fill();

    // Fill Shading Overlay
    ctx.fillStyle = shadowOverlay;
    ctx.fill();

    // Draw outline grid lines
    ctx.strokeStyle = "rgba(10, 11, 16, 0.4)";
    ctx.lineWidth = 0.5;
    ctx.stroke();
}

function getGradeColor(grade) {
    if (grade >= 3.5) return varColor("pink");     // High Grade
    if (grade >= 2.0) return varColor("amber");    // Medium Grade
    if (grade >= 1.0) return varColor("cyan");     // Low Grade
    return "#1e293b";                               // Waste (Slate)
}

function drawBlockModelLegend(w, h) {
    let lx = 20;
    let ly = h - 170;
    
    ctxEl.fillStyle = "rgba(10, 11, 16, 0.8)";
    ctxEl.strokeStyle = "#1e293b";
    ctxEl.fillRect(lx, ly, 150, 110);
    ctxEl.strokeRect(lx, ly, 150, 110);

    ctxEl.fillStyle = "#ffffff";
    ctxEl.font = "bold 9px 'JetBrains Mono', monospace";
    ctxEl.fillText("GRADE KRIGING (Au g/t)", lx + 12, ly + 18);

    let colors = [
        { label: ">= 3.5 High Grade", fill: varColor("pink") },
        { label: "2.0 - 3.5 Medium", fill: varColor("amber") },
        { label: "1.0 - 2.0 Low Grade", fill: varColor("cyan") },
        { label: "< 1.0 Waste Rock", fill: "#1e293b" }
    ];

    colors.forEach((c, idx) => {
        ctxEl.fillStyle = c.fill;
        ctxEl.fillRect(lx + 12, ly + 32 + (idx * 16), 16, 10);
        
        ctxEl.fillStyle = "#cbd5e1";
        ctxEl.font = "9px 'JetBrains Mono'";
        ctxEl.fillText(c.label, lx + 36, ly + 40 + (idx * 16));
    });
}

/* ==========================================================================
   MODULE 4: MINE DESIGN ENGINEERING
   ========================================================================== */

function renderMineEngineering(w, h) {
    let pitBenches = 6;
    let baseRad = 35;
    let benchHeight = 15;
    let angleSlopeRad = 2.4; // slope slope expansion rate

    ctxEl.lineWidth = 1.5;

    // Draw open pit contours
    for (let b = 0; b < pitBenches; b++) {
        let r = baseRad + (b * benchHeight * angleSlopeRad);
        let z = -b * benchHeight;

        // Draw concentric bench circles in pseudo 3D
        ctxEl.beginPath();
        let segments = 32;
        let points = [];
        
        // Bench risk/hazard flagging (benches 3 and 4 have visual failure risks)
        let isHazardZone = (b === 3 || b === 4);

        for (let i = 0; i <= segments; i++) {
            let angle = (i / segments) * Math.PI * 2;
            let px = Math.cos(angle) * r;
            let py = Math.sin(angle) * r;
            let pProj = project(px, py, z, w, h);
            points.push(pProj);

            if (i === 0) ctxEl.moveTo(pProj.x, pProj.y);
            else ctxEl.lineTo(pProj.x, pProj.y);
        }
        
        ctxEl.strokeStyle = isHazardZone ? "rgba(245, 158, 11, 0.8)" : "rgba(6, 182, 212, 0.7)";
        ctxEl.stroke();
        entityCount++;

        // Draw vertical bench wall connectors
        if (b > 0) {
            let prevR = baseRad + ((b - 1) * benchHeight * angleSlopeRad);
            let prevZ = -(b - 1) * benchHeight;

            for (let i = 0; i < segments; i += 4) { // draw 8 vertical divider lines
                let angle = (i / segments) * Math.PI * 2;
                let topPt = project(Math.cos(angle) * r, Math.sin(angle) * r, z, w, h);
                let btmPt = project(Math.cos(angle) * prevR, Math.sin(angle) * prevR, prevZ, w, h);

                ctxEl.strokeStyle = isHazardZone ? "rgba(245, 158, 11, 0.4)" : "rgba(30, 41, 59, 0.6)";
                ctxEl.lineWidth = 0.5;
                ctxEl.beginPath();
                ctxEl.moveTo(topPt.x, topPt.y);
                ctxEl.lineTo(btmPt.x, btmPt.y);
                ctxEl.stroke();
                entityCount++;
            }
        }

        // Draw risk safety factors warnings
        if (b === 3) {
            let labelPt = points[Math.floor(segments * 0.15)];
            ctxEl.fillStyle = varColor("amber");
            ctxEl.font = "bold 9px 'JetBrains Mono'";
            ctxEl.fillText("⚠️ HAZARD RAMP 3: SF 1.14", labelPt.x + 5, labelPt.y - 5);
            
            // Red alert flag marker
            ctxEl.fillStyle = varColor("red");
            ctxEl.beginPath();
            ctxEl.arc(labelPt.x, labelPt.y, 4, 0, Math.PI * 2);
            ctxEl.fill();
        }
    }

    // 2. Draw Spiral Haul Road
    ctxEl.strokeStyle = varColor("amber");
    ctxEl.lineWidth = 3.0;
    ctxEl.beginPath();
    
    let roadSteps = 80;
    for (let i = 0; i <= roadSteps; i++) {
        // Spiral equations: interpolates between pit bottom and top surface
        let ratio = i / roadSteps;
        let angle = ratio * Math.PI * 3.5; // spirals 1.75 turns
        let curZ = -ratio * (pitBenches * benchHeight);
        let curR = baseRad + ((pitBenches - 1) * benchHeight * angleSlopeRad * (1 - ratio)) + 8; // slight offset path

        let rx = Math.cos(angle) * curR;
        let ry = Math.sin(angle) * curR;
        let rProj = project(rx, ry, curZ, w, h);

        if (i === 0) ctxEl.moveTo(rProj.x, rProj.y);
        else ctxEl.lineTo(rProj.x, rProj.y);
    }
    ctxEl.stroke();
    entityCount++;

    // Spiral road label
    let roadLabelPt = project(Math.cos(Math.PI*2)*baseRad*2, Math.sin(Math.PI*2)*baseRad*2, -20, w, h);
    ctxEl.fillStyle = varColor("amber");
    ctxEl.font = "9px 'JetBrains Mono'";
    ctxEl.fillText("SPIRAL HAUL ROAD DESIGN", roadLabelPt.x, roadLabelPt.y);

    if (showUndergroundTunnels) {
        renderUndergroundTunnels(w, h, 0, 0);
    }
}

/* ==========================================================================
   MODULE 5: SIMULATION ENGINE (ANIMATED FLUID/HAULAGE SCENE)
   ========================================================================== */

function resetSimulation() {
    simTrucks = [];
    simParticles = [];
    simTime = 0;

    // Generate initial fleet
    let truckCount = 6;
    for (let t = 0; t < truckCount; t++) {
        simTrucks.push({
            id: `TR-${101 + t}`,
            progress: t / truckCount, // cycle position ratio (0 to 1)
            capacity: 85,             // tons
            load: 0,
            status: "HAULING",        // HAULING, DUMPING, RETURNING, LOADING
            speed: 0.002 + Math.random() * 0.0005,
            x: 0, y: 0, z: 0
        });
    }
}

function renderSimulation(w, h) {
    simTime += 0.5;

    // Draw Static Crusher Facility at Surface
    let crusherPos = { x: 140, y: 80, z: 0 };
    let crusherProj = project(crusherPos.x, crusherPos.y, crusherPos.z, w, h);
    
    // Draw crusher structural box
    ctxEl.fillStyle = "#334155";
    ctxEl.strokeStyle = "#475569";
    ctxEl.lineWidth = 1.0;
    ctxEl.fillRect(crusherProj.x - 15, crusherProj.y - 12, 30, 24);
    ctxEl.strokeRect(crusherProj.x - 15, crusherProj.y - 12, 30, 24);

    ctxEl.fillStyle = "#ffffff";
    ctxEl.font = "bold 8px 'JetBrains Mono'";
    ctxEl.fillText("CRUSHER SITE", crusherProj.x - 26, crusherProj.y - 18);

    // Draw Loading Shovel at Pit Bottom (Center, Z = -90)
    let shovelPos = { x: 0, y: 0, z: -80 };
    let shovelProj = project(shovelPos.x, shovelPos.y, shovelPos.z, w, h);

    // Render loading arm rotation animation
    simLoader.angle = Math.sin(simTime * 0.05) * 45; // oscillates arm
    ctxEl.strokeStyle = varColor("cyan");
    ctxEl.lineWidth = 3;
    ctxEl.beginPath();
    ctxEl.moveTo(shovelProj.x, shovelProj.y);
    let armX = shovelProj.x + Math.cos((simLoader.angle * Math.PI)/180) * 16;
    let armY = shovelProj.y + Math.sin((simLoader.angle * Math.PI)/180) * 16;
    ctxEl.lineTo(armX, armY);
    ctxEl.stroke();
    
    // Shovel body base
    ctxEl.fillStyle = "#3b82f6";
    ctxEl.fillRect(shovelProj.x - 6, shovelProj.y - 6, 12, 12);
    ctxEl.fillStyle = "#ffffff";
    ctxEl.font = "bold 7px 'JetBrains Mono'";
    ctxEl.fillText("SHOVEL-01", shovelProj.x - 18, shovelProj.y + 16);

    // Spiral haul path nodes helper for truck movement coordinates mapping
    let pitBenches = 6;
    let baseRad = 35;
    let benchHeight = 15;
    let angleSlopeRad = 2.4;
    
    function getSpiralPoint(progress) {
        // progress maps: 0 = Bottom (LOADING), 1 = Top Crusher Entrance
        let angle = (1 - progress) * Math.PI * 3.5; 
        let curZ = -(1 - progress) * (pitBenches * benchHeight);
        let curR = baseRad + ((pitBenches - 1) * benchHeight * angleSlopeRad * progress) + 8;
        
        let rx = Math.cos(angle) * curR;
        let ry = Math.sin(angle) * curR;
        
        // smooth path transition to the crusher plant when progress > 0.95
        if (progress > 0.95) {
            let blend = (progress - 0.95) / 0.05;
            rx = rx * (1 - blend) + crusherPos.x * blend;
            ry = ry * (1 - blend) + crusherPos.y * blend;
            curZ = curZ * (1 - blend) + crusherPos.z * blend;
        }

        return { x: rx, y: ry, z: curZ };
    }

    // Process & Draw Trucks
    simTrucks.forEach(truck => {
        // Move truck progress state
        if (truck.status === "HAULING") {
            truck.progress += truck.speed;
            if (truck.progress >= 1.0) {
                truck.progress = 1.0;
                truck.status = "DUMPING";
                truck.timer = 30; // dump cycles duration
            }
        } else if (truck.status === "DUMPING") {
            truck.timer--;
            // Emit conveyor dust particles
            if (Math.random() < 0.3) {
                simParticles.push({
                    x: crusherPos.x, y: crusherPos.y, z: crusherPos.z,
                    vx: Math.random() * 0.8 - 0.4,
                    vy: Math.random() * 0.8 - 0.4,
                    vz: Math.random() * 1.0 + 0.5,
                    life: 20
                });
            }
            if (truck.timer <= 0) {
                truck.status = "RETURNING";
            }
        } else if (truck.status === "RETURNING") {
            truck.progress -= truck.speed * 1.5; // returns faster empty!
            if (truck.progress <= 0.0) {
                truck.progress = 0.0;
                truck.status = "LOADING";
                truck.timer = 40;
            }
        } else if (truck.status === "LOADING") {
            truck.timer--;
            // Emit shovel dust
            if (Math.random() < 0.2) {
                simParticles.push({
                    x: shovelPos.x, y: shovelPos.y, z: shovelPos.z,
                    vx: Math.random() * 0.6 - 0.3,
                    vy: Math.random() * 0.6 - 0.3,
                    vz: Math.random() * 0.8 + 0.4,
                    life: 15
                });
            }
            if (truck.timer <= 0) {
                truck.status = "HAULING";
            }
        }

        // Get 3D coordinate and project
        let tPos = getSpiralPoint(truck.progress);
        truck.x = tPos.x;
        truck.y = tPos.y;
        truck.z = tPos.z;

        let proj = project(truck.x, truck.y, truck.z, w, h);

        // Draw Truck Dot with state styling
        ctxEl.beginPath();
        ctxEl.arc(proj.x, proj.y, 4.5, 0, Math.PI * 2);
        
        if (truck.status === "HAULING") ctxEl.fillStyle = varColor("pink");      // loaded (heavy)
        else if (truck.status === "RETURNING") ctxEl.fillStyle = varColor("green"); // empty (fast)
        else if (truck.status === "LOADING") ctxEl.fillStyle = varColor("cyan");   // loading
        else ctxEl.fillStyle = varColor("amber");                                // dumping

        ctxEl.fill();
        
        // Draw tiny wire outline
        ctxEl.strokeStyle = "#ffffff";
        ctxEl.lineWidth = 0.5;
        ctxEl.stroke();

        // Label Truck ID
        ctxEl.fillStyle = "#94a3b8";
        ctxEl.font = "8px 'JetBrains Mono'";
        ctxEl.fillText(truck.id, proj.x - 12, proj.y - 8);

        entityCount++;
    });

    // Animate and render active particle emissions
    ctxEl.fillStyle = "#64748b";
    for (let i = simParticles.length - 1; i >= 0; i--) {
        let p = simParticles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.z += p.vz;
        p.life--;

        if (p.life <= 0) {
            simParticles.splice(i, 1);
        } else {
            let pProj = project(p.x, p.y, p.z, w, h);
            ctxEl.fillRect(pProj.x, pProj.y, 1.5, 1.5);
            entityCount++;
        }
    }

    // Viewport Realtime HUD Telemetry overlay for Simulator
    drawSimulationStats(w, h);
}

function drawSimulationStats(w, h) {
    let lx = 20;
    let ly = h - 140;
    
    ctxEl.fillStyle = "rgba(10, 11, 16, 0.85)";
    ctxEl.strokeStyle = "#1e293b";
    ctxEl.fillRect(lx, ly, 180, 80);
    ctxEl.strokeRect(lx, ly, 180, 80);

    ctxEl.fillStyle = "#ffffff";
    ctxEl.font = "bold 9px 'JetBrains Mono'";
    ctxEl.fillText("SIM FLEET REPORT", lx + 12, ly + 18);

    ctxEl.fillStyle = "#cbd5e1";
    ctxEl.font = "9px 'JetBrains Mono'";
    
    let activeHaulers = simTrucks.filter(t => t.status === "HAULING").length;
    let loadingTrucks = simTrucks.filter(t => t.status === "LOADING").length;
    let tonnageMoved = Math.floor(simTime * 0.85);

    ctxEl.fillText(`Loaded Hauling Fleet : ${activeHaulers} units`, lx + 12, ly + 36);
    ctxEl.fillText(`Shovel Queue Loading: ${loadingTrucks} units`, lx + 12, ly + 50);
    ctxEl.fillText(`Est. Tonnage Hauled : ${tonnageMoved} tons`, lx + 12, ly + 64);
}

/* ==========================================================================
   MODULE 6: ECONOMIC ENGINE
   ========================================================================== */

function renderEconomics(w, h) {
    // Generate cash flows dynamically based on operating parameters
    let lifeOfMine = 10; // years
    let capitalCost = 150; // $ Millions initial cap
    
    // Grade vector profile per year
    let yearlyGrades = [2.8, 3.2, 3.0, 2.5, 2.2, 1.8, 1.6, 1.5, 1.2, 1.0];
    let processingThroughput = 2.2; // Million tons ore / year

    let discountRate = 0.08; // 8% WACC
    let npvVal = -capitalCost;
    let cashflows = [];

    // Calculate Cashflows and NPV
    for (let yr = 1; yr <= lifeOfMine; yr++) {
        let grade = yearlyGrades[yr - 1];
        let ouncesAu = processingThroughput * 1000000 * (grade / 31.103) * 0.92; // 92% plant recovery
        let grossRevenue = (ouncesAu * econGoldPrice) / 1000000; // $ Millions
        
        let minCostTotal = processingThroughput * econMiningCost;
        let procCostTotal = processingThroughput * econProcessingCost;
        let totalOpex = minCostTotal + procCostTotal + 5.0; // opex + overheads
        
        let netProfit = grossRevenue - totalOpex;
        let discountedCF = netProfit / Math.pow(1 + discountRate, yr);
        
        npvVal += discountedCF;
        cashflows.push({ year: yr, flow: netProfit, cumulative: npvVal });
    }

    // 1. Draw live Line graph dashboard inside viewport
    drawNPVSensitivityChart(w, h);
    drawCashflowProfile(w, h, cashflows);

    // 2. Draw calculations overlay box
    drawEconomicReportCard(w, h, npvVal, cashflows[cashflows.length - 1].cumulative);
}

function drawNPVSensitivityChart(w, h) {
    let cx = w / 2 - 190;
    let cy = h / 2 - 80;
    let cw = 170;
    let ch = 140;

    ctxEl.fillStyle = "rgba(10, 11, 16, 0.8)";
    ctxEl.strokeStyle = "#1e293b";
    ctxEl.fillRect(cx, cy, cw, ch);
    ctxEl.strokeRect(cx, cy, cw, ch);

    ctxEl.fillStyle = "#ffffff";
    ctxEl.font = "bold 9px 'JetBrains Mono'";
    ctxEl.fillText("NPV SENSITIVITY (GOLD PRICE)", cx + 10, cy + 18);

    // Draw coordinates
    ctxEl.strokeStyle = "rgba(226, 232, 240, 0.2)";
    ctxEl.beginPath();
    ctxEl.moveTo(cx + 25, cy + 35);
    ctxEl.lineTo(cx + 25, cy + ch - 25);
    ctxEl.lineTo(cx + cw - 15, cy + ch - 25);
    ctxEl.stroke();

    // Render NPV curve for Gold range: $1200 to $2800
    ctxEl.strokeStyle = varColor("cyan");
    ctxEl.lineWidth = 2.0;
    ctxEl.beginPath();

    let steps = 15;
    for (let i = 0; i <= steps; i++) {
        let price = 1200 + (i / steps) * 1600;
        
        // Simplified project evaluation formula
        let testNpv = -150;
        for (let yr = 1; yr <= 10; yr++) {
            let oz = 2.2 * 1000000 * (2.1 / 31.103) * 0.92;
            let rev = (oz * price) / 1000000;
            let opex = 2.2 * (econMiningCost + econProcessingCost) + 5.0;
            testNpv += (rev - opex) / Math.pow(1 + 0.08, yr);
        }

        // Map NPV output coordinate
        let gx = cx + 25 + (i / steps) * (cw - 45);
        // map NPV range -100M to 400M to canvas Y height
        let ratioVal = (testNpv + 100) / 500;
        let gy = cy + ch - 25 - ratioVal * (ch - 60);

        if (i === 0) ctxEl.moveTo(gx, gy);
        else ctxEl.lineTo(gx, gy);

        // Mark the current price
        if (Math.abs(price - econGoldPrice) < 60) {
            ctxEl.fillStyle = varColor("amber");
            ctxEl.beginPath();
            ctxEl.arc(gx, gy, 4, 0, Math.PI * 2);
            ctxEl.fill();
        }
    }
    ctxEl.stroke();
    entityCount += steps;

    // labels
    ctxEl.fillStyle = varColor("cyan");
    ctxEl.font = "8px 'JetBrains Mono'";
    ctxEl.fillText("$1.2k", cx + 20, cy + ch - 12);
    ctxEl.fillText("$2.8k", cx + cw - 38, cy + ch - 12);
    ctxEl.fillText("Price", cx + cw / 2 - 15, cy + ch - 4);
}

function drawCashflowProfile(w, h, cashflows) {
    let cx = w / 2 + 10;
    let cy = h / 2 - 80;
    let cw = 180;
    let ch = 140;

    ctxEl.fillStyle = "rgba(10, 11, 16, 0.8)";
    ctxEl.strokeStyle = "#1e293b";
    ctxEl.fillRect(cx, cy, cw, ch);
    ctxEl.strokeRect(cx, cy, cw, ch);

    ctxEl.fillStyle = "#ffffff";
    ctxEl.font = "bold 9px 'JetBrains Mono'";
    ctxEl.fillText("ANNUAL NET BENEFIT ($M)", cx + 10, cy + 18);

    // Draw baseline axes
    ctxEl.strokeStyle = "rgba(226, 232, 240, 0.15)";
    ctxEl.beginPath();
    ctxEl.moveTo(cx + 20, cy + ch/2 + 10);
    ctxEl.lineTo(cx + cw - 10, cy + ch/2 + 10);
    ctxEl.stroke();

    // Bar chart rendering
    let barWidth = 10;
    let maxVal = 80;

    cashflows.forEach((cf, idx) => {
        let bx = cx + 25 + (idx * 14);
        let barHeight = (cf.flow / maxVal) * (ch - 50);

        ctxEl.fillStyle = cf.flow >= 0 ? "rgba(16, 185, 129, 0.65)" : "rgba(239, 68, 68, 0.65)";
        ctxEl.fillRect(bx, cy + ch/2 + 10 - barHeight, barWidth, barHeight);

        // draw border line
        ctxEl.strokeStyle = cf.flow >= 0 ? varColor("green") : varColor("red");
        ctxEl.lineWidth = 0.5;
        ctxEl.strokeRect(bx, cy + ch/2 + 10 - barHeight, barWidth, barHeight);

        // Year labels
        if (idx % 2 === 0) {
            ctxEl.fillStyle = "#cbd5e1";
            ctxEl.font = "8px 'JetBrains Mono'";
            ctxEl.fillText(`Y${idx + 1}`, bx - 2, cy + ch - 12);
        }
        entityCount++;
    });
}

function drawEconomicReportCard(w, h, npv, endVal) {
    let lx = 20;
    let ly = 160;
    
    ctxEl.fillStyle = "rgba(10, 11, 16, 0.9)";
    ctxEl.strokeStyle = "#1e293b";
    ctxEl.fillRect(lx, ly, 180, 100);
    ctxEl.strokeRect(lx, ly, 180, 100);

    ctxEl.fillStyle = "#ffffff";
    ctxEl.font = "bold 9px 'JetBrains Mono'";
    ctxEl.fillText("PROJECT METRICS", lx + 12, ly + 18);

    ctxEl.fillStyle = "#cbd5e1";
    ctxEl.font = "9px 'JetBrains Mono'";
    ctxEl.fillText("WACC: 8.00% (Real)", lx + 12, ly + 36);

    ctxEl.fillStyle = npv >= 0 ? varColor("green") : varColor("red");
    ctxEl.font = "bold 11px 'JetBrains Mono'";
    ctxEl.fillText(`NPV: $${npv.toFixed(1)}M`, lx + 12, ly + 56);
    
    ctxEl.fillStyle = "#e2e8f0";
    ctxEl.font = "9px 'JetBrains Mono'";
    let paybackPeriod = npv > 0 ? "3.2 Years" : "Never Payback";
    ctxEl.fillText(`Payback: ${paybackPeriod}`, lx + 12, ly + 76);
}

/* ==========================================================================
   UTILITY HELPER FUNCTIONS
   ========================================================================== */

/**
 * Maps standard theme tag names to color hashes matching style.css rules.
 */
function varColor(name) {
    switch(name) {
        case "cyan": return "#06b6d4";
        case "amber": return "#f59e0b";
        case "blue": return "#3b82f6";
        case "green": return "#10b981";
        case "pink": return "#ec4899";
        case "red": return "#ef4444";
        default: return "#cbd5e1";
    }
}

/* ==========================================================================
   UNDERGROUND TUNNELS & DIGITAL TWIN COMPOSITE
   ========================================================================== */

function renderUndergroundTunnels(w, h, offsetX, offsetY) {
    const tunnels = [
        { x1: -90, y1: -30, z1: -55, x2: 40, y2: 20, z2: -48 },
        { x1: 40, y1: 20, z1: -48, x2: 95, y2: -10, z2: -42 },
        { x1: -50, y1: 50, z1: -52, x2: -90, y2: -30, z2: -55 },
        { x1: 10, y1: -60, z1: -58, x2: 40, y2: 20, z2: -48 }
    ];

    ctxEl.lineWidth = 4;
    tunnels.forEach((t, idx) => {
        const steps = 12;
        ctxEl.beginPath();
        for (let s = 0; s <= steps; s++) {
            const r = s / steps;
            const x = (t.x1 + offsetX) * (1 - r) + (t.x2 + offsetX) * r;
            const y = (t.y1 + offsetY) * (1 - r) + (t.y2 + offsetY) * r;
            const z = t.z1 * (1 - r) + t.z2 * r + Math.sin(r * Math.PI * 2 + simTime * 0.02) * 1.5;
            const p = project(x, y, z, w, h);
            if (s === 0) ctxEl.moveTo(p.x, p.y);
            else ctxEl.lineTo(p.x, p.y);
        }
        ctxEl.strokeStyle = idx % 2 === 0 ? "rgba(168, 85, 247, 0.75)" : "rgba(139, 92, 246, 0.55)";
        ctxEl.stroke();
        entityCount += steps;
    });

    const portal = project(-90 + offsetX, -30 + offsetY, -55, w, h);
    ctxEl.fillStyle = "rgba(168, 85, 247, 0.9)";
    ctxEl.beginPath();
    ctxEl.arc(portal.x, portal.y, 5, 0, Math.PI * 2);
    ctxEl.fill();
    ctxEl.fillStyle = "#c4b5fd";
    ctxEl.font = "8px 'JetBrains Mono'";
    ctxEl.fillText("UG ACCESS L1", portal.x - 28, portal.y - 10);
}

function renderCompositeFullScene(w, h) {
    ctxEl.save();
    ctxEl.globalAlpha = 0.92;

    let res = 12;
    let size = 200;
    let step = size / res;
    let points = [];
    for (let i = 0; i <= res; i++) {
        points[i] = [];
        for (let j = 0; j <= res; j++) {
            let x = -size/2 + i * step;
            let y = -size/2 + j * step;
            let d = Math.sqrt(x*x + y*y);
            let z = Math.sin(d / 25) * 18 + Math.cos(x / 15) * 8;
            points[i][j] = project(x, y, z, w, h);
            entityCount++;
        }
    }
    for (let i = 0; i < res; i++) {
        for (let j = 0; j < res; j++) {
            let p00 = points[i][j], p10 = points[i+1][j], p01 = points[i][j+1];
            ctxEl.fillStyle = "rgba(6, 182, 212, 0.06)";
            ctxEl.beginPath();
            ctxEl.moveTo(p00.x, p00.y);
            ctxEl.lineTo(p10.x, p10.y);
            ctxEl.lineTo(p01.x, p01.y);
            ctxEl.closePath();
            ctxEl.fill();
        }
    }
    ctxEl.strokeStyle = "rgba(6, 182, 212, 0.2)";
    ctxEl.lineWidth = 0.5;
    for (let i = 0; i <= res; i++) {
        for (let j = 0; j <= res; j++) {
            if (i < res) {
                ctxEl.beginPath();
                ctxEl.moveTo(points[i][j].x, points[i][j].y);
                ctxEl.lineTo(points[i+1][j].x, points[i+1][j].y);
                ctxEl.stroke();
            }
            if (j < res) {
                ctxEl.beginPath();
                ctxEl.moveTo(points[i][j].x, points[i][j].y);
                ctxEl.lineTo(points[i][j+1].x, points[i][j+1].y);
                ctxEl.stroke();
            }
        }
    }

    ctxEl.globalAlpha = 1;
    renderGeology(w, h);

    let savedCutoff = blockGradeCutoff;
    blockGradeCutoff = 0.8;
    renderBlockModel(w, h);
    blockGradeCutoff = savedCutoff;

    renderMineEngineering(w, h);

    if (simTrucks.length === 0) resetSimulation();
    let savedEngine = activeEngine;
    activeEngine = "simulation";
    renderSimulation(w, h);
    activeEngine = savedEngine;

    ctxEl.restore();

    ctxEl.fillStyle = "rgba(6, 182, 212, 0.9)";
    ctxEl.font = "bold 10px 'JetBrains Mono'";
    ctxEl.fillText("COMPOSITE DIGITAL TWIN — TERRAIN · STRATA · BLOCKS · PIT · UG · FLEET", 16, 36);
}

function renderDigitalTwinComposite(w, h) {
    ctxEl.save();
    ctxEl.globalAlpha = 0.55;

    let res = 10;
    let size = 180;
    let step = size / res;
    let points = [];
    for (let i = 0; i <= res; i++) {
        points[i] = [];
        for (let j = 0; j <= res; j++) {
            let x = -size/2 + i * step;
            let y = -size/2 + j * step;
            let d = Math.sqrt(x*x + y*y);
            let z = Math.sin(d / 25) * 18 + Math.cos(x / 15) * 8;
            points[i][j] = project(x, y, z, w, h);
        }
    }
    ctxEl.strokeStyle = "rgba(6, 182, 212, 0.25)";
    ctxEl.lineWidth = 0.5;
    for (let i = 0; i < res; i++) {
        for (let j = 0; j < res; j++) {
            ctxEl.beginPath();
            ctxEl.moveTo(points[i][j].x, points[i][j].y);
            ctxEl.lineTo(points[i+1][j].x, points[i+1][j].y);
            ctxEl.lineTo(points[i][j+1].x, points[i][j+1].y);
            ctxEl.closePath();
            ctxEl.stroke();
        }
    }

    renderMineEngineering(w, h);

    if (geologyShowBoreholes) {
        [{ x: -60, y: -20 }, { x: 50, y: 30 }].forEach(bh => {
            let top = project(bh.x, bh.y, 50, w, h);
            let bot = project(bh.x, bh.y, -60, w, h);
            ctxEl.strokeStyle = "rgba(226, 232, 240, 0.5)";
            ctxEl.lineWidth = 1.5;
            ctxEl.beginPath();
            ctxEl.moveTo(top.x, top.y);
            ctxEl.lineTo(bot.x, bot.y);
            ctxEl.stroke();
        });
    }

    if (simTrucks.length) {
        simTrucks.slice(0, 4).forEach(truck => {
            let px = Math.cos(truck.progress * Math.PI * 6) * 60;
            let py = Math.sin(truck.progress * Math.PI * 6) * 60;
            let p = project(px, py, -30, w, h);
            ctxEl.fillStyle = varColor("pink");
            ctxEl.beginPath();
            ctxEl.arc(p.x, p.y, 3, 0, Math.PI * 2);
            ctxEl.fill();
        });
    }

    ctxEl.restore();

    ctxEl.fillStyle = "rgba(6, 182, 212, 0.85)";
    ctxEl.font = "bold 9px 'JetBrains Mono'";
    ctxEl.fillText("◈ DIGITAL TWIN SYNC — MULTI-LAYER COMPOSITE", w / 2 - 120, 48);
}

function updateLiveTwinTelemetry(delta) {
    twinTelemetry.slope = 1.08 + Math.sin(simTime * 0.008) * 0.08;
    twinTelemetry.vent = 820 + Math.floor(Math.sin(simTime * 0.012) * 40);
    twinTelemetry.prod = 41.5 + Math.sin(simTime * 0.006) * 2.2;
    twinTelemetry.fleet = simTrucks.length ? "LIVE" : "STANDBY";

    const slopeEl = document.getElementById("twinSlope");
    const ventEl = document.getElementById("twinVent");
    const prodEl = document.getElementById("twinProd");
    const fleetEl = document.getElementById("twinFleet");

    if (slopeEl) slopeEl.textContent = `Slope RF: ${twinTelemetry.slope.toFixed(2)}`;
    if (ventEl) ventEl.textContent = `Vent: ${twinTelemetry.vent} m³/s`;
    if (prodEl) prodEl.textContent = `Prod: ${twinTelemetry.prod.toFixed(1)} kt/d`;
    if (fleetEl) {
        fleetEl.textContent = `Fleet: ${twinTelemetry.fleet}`;
        fleetEl.classList.toggle("live-flash", twinTelemetry.fleet === "LIVE" && simTime % 40 < 20);
    }
}