/* ==========================================================================
   NGMEP — Backend API Client (feeds data in / pulls data out)
   Set: localStorage.setItem("ngmep_api_url", "http://localhost:8787")
   ========================================================================== */

const NGMEP_API_STORAGE_KEY = "ngmep_api_url";

function getApiBaseUrl() {
    if (typeof window !== "undefined" && window.NGMEP_API_URL) {
        return String(window.NGMEP_API_URL).replace(/\/$/, "");
    }
    try {
        return (localStorage.getItem(NGMEP_API_STORAGE_KEY) || "").replace(/\/$/, "");
    } catch (_) {
        return "";
    }
}

function isApiEnabled() {
    return !!getApiBaseUrl();
}

async function apiRequest(method, path, body) {
    const base = getApiBaseUrl();
    if (!base) return null;

    const opts = {
        method,
        headers: {
            "Content-Type": "application/json",
            "X-NGMEP-Source": "ngmep-web-client"
        }
    };
    if (body !== undefined) {
        opts.body = JSON.stringify(body);
    }

    const res = await fetch(`${base}/api/v1${path}`, opts);
    const text = await res.text();
    let data;
    try {
        data = text ? JSON.parse(text) : {};
    } catch (_) {
        data = { message: text };
    }

    if (!res.ok) {
        const err = new Error(data.message || `API ${res.status}`);
        err.status = res.status;
        err.data = data;
        throw err;
    }
    return data;
}

async function apiHealthCheck() {
    return apiRequest("GET", "/health");
}

async function apiListOrganizations() {
    const data = await apiRequest("GET", "/organizations");
    return data ? data.organizations : [];
}

async function apiCreateOrganization(payload) {
    return apiRequest("POST", "/organizations", payload);
}

async function apiListProjects(orgId) {
    const data = await apiRequest("GET", `/organizations/${orgId}/projects`);
    return data ? data.projects : [];
}

async function apiCreateProject(orgId, payload) {
    return apiRequest("POST", `/organizations/${orgId}/projects`, payload);
}

async function apiSyncProject(orgId, projectId) {
    return apiRequest("GET", `/organizations/${orgId}/projects/${projectId}/sync`);
}

async function apiSaveWorkspace(orgId, projectId, workspace) {
    return apiRequest("PUT", `/organizations/${orgId}/projects/${projectId}/workspace`, { workspace });
}

async function apiListDatasets(orgId, projectId, type) {
    const data = await apiRequest("GET", `/organizations/${orgId}/projects/${projectId}/datasets/${type}`);
    return data ? data.datasets : [];
}

async function apiGetDataset(orgId, projectId, type, datasetId) {
    return apiRequest("GET", `/organizations/${orgId}/projects/${projectId}/datasets/${type}/${datasetId}`);
}

async function apiIngestDataset(orgId, projectId, type, payload) {
    return apiRequest("POST", `/organizations/${orgId}/projects/${projectId}/datasets/${type}`, payload);
}

async function apiUploadDatasetFile(orgId, projectId, type, file, name) {
    const base = getApiBaseUrl();
    if (!base) return null;

    const form = new FormData();
    form.append("file", file);
    if (name) form.append("name", name);

    const res = await fetch(
        `${base}/api/v1/organizations/${orgId}/projects/${projectId}/datasets/${type}/upload`,
        { method: "POST", body: form, headers: { "X-NGMEP-Source": "ngmep-web-upload" } }
    );
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Upload failed");
    return data;
}

/**
 * Pull full tenant state from backend into the web app session.
 */
async function syncTenancyFromApi() {
    if (!isApiEnabled()) return false;

    try {
        await apiHealthCheck();
        const orgs = await apiListOrganizations();
        if (!orgs.length) return false;

        let orgId = tenantSession.activeOrgId;
        if (!orgId || !orgs.find(o => o.id === orgId)) {
            orgId = orgs[0].id;
        }

        const projects = await apiListProjects(orgId);
        if (!projects.length) return false;

        let projectId = tenantSession.activeProjectId;
        if (!projectId || !projects.find(p => p.id === projectId)) {
            projectId = projects[0].id;
        }

        const bundle = await apiSyncProject(orgId, projectId);
        applyApiBundle(bundle, orgId, projectId);
        updateApiStatusIndicator(true);
        if (typeof pushLiveEvent === "function") {
            pushLiveEvent(`Synced from API: ${bundle.project.name}`, "success");
        }
        return true;
    } catch (err) {
        console.warn("[NGMEP API]", err);
        updateApiStatusIndicator(false, err.message);
        return false;
    }
}

function applyApiBundle(bundle, orgId, projectId) {
    tenantSession.activeOrgId = orgId;
    tenantSession.activeProjectId = projectId;
    activeOrg = bundle.organization;
    activeProject = bundle.project;

    try {
        const reg = loadRegistry();
        if (!reg.orgs.find(o => o.id === orgId)) {
            reg.orgs.push({ id: orgId, name: bundle.organization.name });
        }
        reg.activeOrgId = orgId;
        reg.activeProjectId = projectId;
        saveRegistry(reg);

        const orgData = loadOrgData(orgId) || { org: bundle.organization, projects: [] };
        orgData.org = bundle.organization;
        const idx = orgData.projects.findIndex(p => p.id === projectId);
        const proj = { ...bundle.project, workspace: bundle.workspace };
        if (idx >= 0) orgData.projects[idx] = proj;
        else orgData.projects.push(proj);
        saveOrgData(orgId, orgData);
    } catch (_) { /* local mirror optional */ }

    applyProjectContext(activeProject, activeOrg);
    if (bundle.workspace) applyWorkspaceState(bundle.workspace);
    else applyWorkspaceState(getDefaultWorkspaceForProject(activeProject));

    window.__ngmepLastBundle = bundle;
    updateTenantUI();
}

async function saveWorkspaceToApi() {
    if (!isApiEnabled() || !tenantSession.activeOrgId || !tenantSession.activeProjectId) {
        return false;
    }
    const workspace = captureWorkspaceState();
    await apiSaveWorkspace(tenantSession.activeOrgId, tenantSession.activeProjectId, workspace);
    return true;
}

async function ingestDrillholesToApi(records, name) {
    if (!isApiEnabled() || !tenantSession.activeOrgId || !tenantSession.activeProjectId) {
        return null;
    }
    return apiIngestDataset(tenantSession.activeOrgId, tenantSession.activeProjectId, "drillholes", {
        name: name || "Web client ingest",
        records
    });
}

function updateApiStatusIndicator(online, message) {
    const el = document.getElementById("apiStatusBadge");
    if (!el) return;
    el.classList.toggle("online", !!online);
    el.classList.toggle("offline", !online);
    el.textContent = online ? "API" : "LOCAL";
    el.title = online
        ? `Backend: ${getApiBaseUrl()}`
        : (message || "Using browser storage only");
}

function showApiConfigHint() {
    if (isApiEnabled()) return;
    const el = document.getElementById("apiStatusBadge");
    if (el) {
        el.textContent = "LOCAL";
        el.title = "Set localStorage ngmep_api_url to http://localhost:8787";
    }
}

window.addEventListener("DOMContentLoaded", () => {
    showApiConfigHint();
    if (isApiEnabled()) {
        updateApiStatusIndicator(true);
    }
});
