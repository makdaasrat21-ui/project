/* ==========================================================================
   NGMEP — AI Copilot Processing & Command System
   ========================================================================== */

let isProcessingCommand = false;

/**
 * Main parser entry point called when user executes an AI Command
 */
function runAICommand(inputText, moduleCallback, outputElement) {
    if (isProcessingCommand) return;
    
    let text = inputText.trim();
    if (!text) return;

    // 1. Log user input to terminal
    appendTerminalLine(outputElement, text, "user-input");
    
    // Clear prompt input
    let inputEl = document.getElementById("aiInput");
    if (inputEl) inputEl.value = "";

    // 2. Parse command intent and parameters
    let cleaned = text.toLowerCase();
    let match = findCommandIntent(cleaned);

    if (!match) {
        appendTerminalLine(outputElement, `AI Copilot: Direct command '${text}' not recognized. Try one of the quick chips or 'help'.`, "warn-msg");
        return;
    }

    // 3. Trigger async loading sequence
    executePipeline(match, moduleCallback, outputElement);
}

/**
 * Maps input string to specific engine modules and parameter overrides
 */
function findCommandIntent(input) {
    // Check parameters first
    // Truck count matching: "simulate 10 trucks"
    let truckMatch = input.match(/(?:simulate|trucks?)\s+(\d+)/);
    if (truckMatch) {
        let count = parseInt(truckMatch[1]);
        return {
            module: "simulation",
            label: `Simulation Engine (Fleet: ${count} Trucks)`,
            pipeline: [
                "Clearing active particle emission buffers...",
                `Spawning ${count} CAT-789 hauler profiles...`,
                "Synchronizing conveyor belt loading arm..."
            ],
            callback: () => {
                let slider = document.getElementById("param-truck-count");
                if (slider) {
                    slider.value = count;
                    let display = document.getElementById("lbl-truck-count");
                    if (display) display.innerText = count;
                }
                resetSimulation();
            }
        };
    }

    // Cutoff matching: "optimize block model cutoff 2.5", "cutoff 1.8"
    let cutoffMatch = input.match(/(?:cutoff|grade|optimize)\s+(\d+(\.\d+)?)/);
    if (cutoffMatch) {
        let grade = parseFloat(cutoffMatch[1]);
        return {
            module: "blockmodel",
            label: `Block Model Optimization (Cutoff: ${grade} g/t)`,
            pipeline: [
                "Re-indexing block grade matrices...",
                `Filtering blocks below ${grade.toFixed(2)} g/t limit...`,
                "Running estimation depth sorting..."
            ],
            callback: () => {
                let slider = document.getElementById("param-grade-cutoff");
                if (slider) {
                    slider.value = grade;
                    let display = document.getElementById("lbl-grade-cutoff");
                    if (display) display.innerText = grade.toFixed(1) + " g/t";
                }
                blockGradeCutoff = grade;
            }
        };
    }

    // Gold price matching: "gold price 2200", "price 1850"
    let priceMatch = input.match(/(?:gold|price|economics)\s+(\d+)/);
    if (priceMatch) {
        let price = parseInt(priceMatch[1]);
        return {
            module: "economics",
            label: `Economic Sensitivity Update ($${price}/oz)`,
            pipeline: [
                "Re-loading Cashflow discount variables...",
                `Calculating cumulative cash flows at $${price}/oz...`,
                "Redrawing NPV sensitivity chart curves..."
            ],
            callback: () => {
                let slider = document.getElementById("param-gold-price");
                if (slider) {
                    slider.value = price;
                    let display = document.getElementById("lbl-gold-price");
                    if (display) display.innerText = "$" + price;
                }
                econGoldPrice = price;
            }
        };
    }

    // Standard Module Switches
    if (input.includes("geology") || input.includes("strata") || input.includes("drillhole")) {
        return {
            module: "geology",
            label: "Geological Modeling Engine",
            pipeline: [
                "Interpolating lithological strata zones...",
                "Mapping borehole casing intervals...",
                "Slicing vertical geological cutting plane..."
            ],
            callback: () => {
                // Ensure drillholes are shown
                let chk = document.getElementById("param-show-boreholes");
                if (chk) chk.checked = true;
                geologyShowBoreholes = true;
            }
        };
    }

    if (input.includes("geometry") || input.includes("grid") || input.includes("mesh")) {
        let gridMatch = input.match(/res\w*\s+(\d+)/);
        let meshVal = gridMatch ? parseInt(gridMatch[1]) : 15;
        return {
            module: "geometry",
            label: "Geometry CAD Kernel",
            pipeline: [
                "Generating coordinate reference system grid...",
                `Initializing elevation terrain mesh (Resolution: ${meshVal}x${meshVal})...`,
                "Transforming coordinate projections to orthographic layout..."
            ],
            callback: () => {
                let slider = document.getElementById("param-mesh-res");
                if (slider) {
                    slider.value = meshVal;
                    let display = document.getElementById("lbl-mesh-res");
                    if (display) display.innerText = meshVal + "x" + meshVal;
                }
                geomMeshRes = meshVal;
            }
        };
    }

    if (input.includes("block") || input.includes("grade") || input.includes("voxel")) {
        return {
            module: "blockmodel",
            label: "Block Model Engine",
            pipeline: [
                "Running Kriging 3D block estimation algorithm...",
                "Loading gold grade estimation cells...",
                "Projecting voxels into 3D isometric workspace..."
            ],
            callback: null
        };
    }

    if (input.includes("stope") || input.includes("optimization")) {
        return {
            module: "engineering",
            label: "Stope Optimization",
            pipeline: [
                "AI Agent: parsing geotechnical constraints...",
                "Assigning GPU cluster partition (4x H100)...",
                "Running stope shape optimization (CUDA)...",
                "Updating pit shell & economic engine..."
            ],
            callback: null
        };
    }

    if (input.includes("engineering") || input.includes("pit") || input.includes("design") || input.includes("bench")) {
        return {
            module: "engineering",
            label: "Mine Design Engineering",
            pipeline: [
                "Configuring concentric open pit contour loops...",
                "Fitting spiral haul road geometry curves...",
                "Calculating slope structural safety factors..."
            ],
            callback: null
        };
    }

    if (input.includes("simulate") || input.includes("truck") || input.includes("operational")) {
        return {
            module: "simulation",
            label: "Haulage Simulation Engine",
            pipeline: [
                "Synchronizing loading arm kinematics...",
                "Routing truck paths down mine benches...",
                "Enabling conveyer conveyor-feed particle systems..."
            ],
            callback: null
        };
    }

    if (input.includes("economics") || input.includes("financial") || input.includes("npv") || input.includes("cashflow")) {
        return {
            module: "economics",
            label: "Project Economic Dashboard",
            pipeline: [
                "Running cashflow model matrices...",
                "Generating NPV sensitivity metrics...",
                "Plotting annual production chart distributions..."
            ],
            callback: null
        };
    }

    if (input.includes("help") || input.includes("man")) {
        return {
            module: null,
            label: "System Directory Manual",
            pipeline: [
                "Opening integrated User Manual documentation...",
                "Highlighting interactive commands list..."
            ],
            callback: () => {
                let panel = document.getElementById("manualPanel");
                if (panel) {
                    panel.classList.remove("closed");
                    switchManualTab("copilot");
                }
            }
        };
    }

    return null;
}

/**
 * Runs the progress pipeline UI animation
 */
function executePipeline(intent, moduleCallback, outputElement) {
    isProcessingCommand = true;

    const targetModule = intent.module || "geometry";
    if (typeof runOrchestrationPipeline === "function") {
        runOrchestrationPipeline(intent.label, intent.module !== null ? targetModule : "geometry", null);
    }
    if (typeof updateAIAgentPanel === "function") {
        updateAIAgentPanel("Copilot executing — " + intent.label, intent.pipeline.map((p, i) => ({
            text: p,
            done: false
        })));
    }
    
    let progressContainer = document.getElementById("aiProgressContainer");
    let progressText = document.getElementById("aiProgressText");
    let progressBar = document.getElementById("aiProgressBar");
    
    if (progressContainer) progressContainer.classList.remove("hidden");
    
    let steps = intent.pipeline;
    let stepDuration = 500; // ms per step
    let curStep = 0;

    appendTerminalLine(outputElement, `AI Copilot: Launching process pipeline for [${intent.label}]...`, "info-msg");

    function runNextStep() {
        if (curStep < steps.length) {
            let label = steps[curStep];
            if (progressText) progressText.innerText = `[${curStep + 1}/${steps.length}] ${label}`;
            if (progressBar) {
                let pct = ((curStep + 1) / steps.length) * 100;
                progressBar.style.width = pct + "%";
            }
            appendTerminalLine(outputElement, ` >> ${label}`, "system-msg");
            if (typeof updateAIAgentPanel === "function") {
                updateAIAgentPanel("Copilot executing — " + intent.label,
                    intent.pipeline.map((p, idx) => ({ text: p, done: idx < curStep })));
            }
            curStep++;
            setTimeout(runNextStep, stepDuration);
        } else {
            // Pipeline Complete!
            if (progressContainer) progressContainer.classList.add("hidden");
            if (progressBar) progressBar.style.width = "0%";
            
            appendTerminalLine(outputElement, `AI Copilot: Pipeline completed successfully for ${intent.label}.`, "success-msg");
            
            // Apply Callbacks (parameters updates) before module switch
            if (intent.callback) {
                intent.callback();
            }

            // Switch Module
            if (intent.module) {
                moduleCallback(intent.module);
            }
            
            if (typeof updateAIAgentPanel === "function") {
                updateAIAgentPanel("Agent idle — ready to orchestrate", [
                    { text: intent.label + " complete", done: true }
                ]);
            }
            
            isProcessingCommand = false;
        }
    }

    runNextStep();
}

/**
 * Appends a formatted line into the terminal stream and scrolls down
 */
function appendTerminalLine(outputElement, text, typeClass) {
    if (!outputElement) return;

    let line = document.createElement("div");
    line.className = `terminal-line ${typeClass}`;
    line.innerText = text;
    
    outputElement.appendChild(line);
    
    // Auto Scroll to bottom
    outputElement.parentElement.scrollTop = outputElement.parentElement.scrollHeight;
}

/**
 * Handles quick tags clicking
 */
function applyChip(cmdText) {
    let inputEl = document.getElementById("aiInput");
    if (inputEl) {
        inputEl.value = cmdText;
        inputEl.focus();
    }
}