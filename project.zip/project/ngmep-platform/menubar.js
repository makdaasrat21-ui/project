/* ==========================================================================
   NGMEP — Top Navigation Menu Bar (click-to-open, wired actions)
   ========================================================================== */

const MENU_CONFIG = {
    File: [
        { label: "Switch Organization…", shortcut: "", action: "file.switchOrg" },
        { label: "Open / New Project…", shortcut: "", action: "file.switchProject" },
        { separator: true },
        { label: "Save Project Workspace", shortcut: "Ctrl+S", action: "file.save" },
        { label: "Reload Platform", shortcut: "", action: "file.reload" },
        { separator: true },
        { label: "Export Scene Snapshot", shortcut: "", action: "file.export" },
        { label: "Import Drillhole Collar CSV", shortcut: "", action: "file.import" }
    ],
    Edit: [
        { label: "Undo", shortcut: "Ctrl+Z", action: "edit.undo" },
        { label: "Redo", shortcut: "Ctrl+Y", action: "edit.redo" },
        { separator: true },
        { label: "Workspace Preferences", shortcut: "", action: "edit.prefs" }
    ],
    View: [
        { label: "Top View", shortcut: "", action: "view.top" },
        { label: "Isometric View", shortcut: "", action: "view.iso" },
        { label: "Reset Camera", shortcut: "Home", action: "view.reset" },
        { separator: true },
        { label: "Composite Digital Twin", shortcut: "", action: "view.composite", checkable: true },
        { label: "Toggle Infrastructure Dock", shortcut: "", action: "view.infra", checkable: true },
        { label: "Toggle User Manual", shortcut: "F1", action: "view.manual" }
    ],
    Strata: [
        { label: "Open Geological Model", shortcut: "2", action: "module.geology" },
        { label: "Slice Cross-Section", shortcut: "", action: "strata.slice" },
        { label: "Ingest Drillhole Batch", shortcut: "", action: "strata.ingest" },
        { label: "Run Kriging Interpolation", shortcut: "", action: "strata.kriging" }
    ],
    Blocks: [
        { label: "Open Block Model Engine", shortcut: "3", action: "module.blockmodel" },
        { label: "Optimize Grade Cutoff", shortcut: "", action: "blocks.optimize" },
        { label: "Distributed Kriging (GPU)", shortcut: "", action: "blocks.gpuKriging" }
    ],
    Design: [
        { label: "Open Mine Engineering", shortcut: "4", action: "module.engineering" },
        { label: "Run Stope Optimization", shortcut: "", action: "design.stope" },
        { label: "Slope Safety Solver", shortcut: "", action: "design.slope" },
        { label: "Show Underground Tunnels", shortcut: "", action: "design.tunnels", checkable: true }
    ],
    Simulation: [
        { label: "Open Simulation Engine", shortcut: "5", action: "module.simulation" },
        { label: "Restart Fleet Dispatch", shortcut: "", action: "sim.restart" },
        { label: "Assign GPU Simulation Queue", shortcut: "", action: "sim.gpuQueue" }
    ],
    Help: [
        { label: "User Manual", shortcut: "F1", action: "help.manual" },
        { label: "Keyboard Shortcuts", shortcut: "", action: "help.shortcuts" },
        { label: "About NGMEP", shortcut: "", action: "help.about" }
    ]
};

let openMenuName = null;
let menuPrefs = {
    compositeView: false,
    showTunnels: true,
    infraDockVisible: true
};

function initMenuBar() {
    const nav = document.getElementById("menuBar");
    if (!nav) return;

    nav.innerHTML = "";
    Object.keys(MENU_CONFIG).forEach(name => {
        const item = document.createElement("div");
        item.className = "menu-item";
        item.dataset.menu = name;

        const label = document.createElement("span");
        label.className = "menu-label";
        label.textContent = name;
        item.appendChild(label);

        const dropdown = document.createElement("div");
        dropdown.className = "dropdown";
        MENU_CONFIG[name].forEach(entry => {
            if (entry.separator) {
                const sep = document.createElement("div");
                sep.className = "dropdown-sep";
                dropdown.appendChild(sep);
                return;
            }
            const link = document.createElement("button");
            link.type = "button";
            link.className = "dropdown-item";
            link.dataset.action = entry.action;
            if (entry.checkable) link.classList.add("checkable");

            const text = document.createElement("span");
            text.className = "dropdown-label";
            text.textContent = entry.label;
            link.appendChild(text);

            if (entry.shortcut) {
                const sc = document.createElement("span");
                sc.className = "dropdown-shortcut";
                sc.textContent = entry.shortcut;
                link.appendChild(sc);
            }

            link.addEventListener("click", e => {
                e.stopPropagation();
                closeAllMenus();
                executeMenuAction(entry.action);
            });
            dropdown.appendChild(link);
        });

        item.appendChild(dropdown);
        label.addEventListener("click", e => {
            e.stopPropagation();
            toggleMenu(name);
        });

        nav.appendChild(item);
    });

    document.addEventListener("click", () => closeAllMenus());
    document.addEventListener("keydown", handleMenuShortcuts);
    syncMenuCheckStates();
}

function toggleMenu(name) {
    if (openMenuName === name) {
        closeAllMenus();
        return;
    }
    closeAllMenus();
    openMenuName = name;
    const item = document.querySelector(`.menu-item[data-menu="${name}"]`);
    if (item) item.classList.add("open");
}

function closeAllMenus() {
    openMenuName = null;
    document.querySelectorAll(".menu-item.open").forEach(el => el.classList.remove("open"));
}

function syncMenuCheckStates() {
    setCheckState("view.composite", menuPrefs.compositeView);
    setCheckState("view.infra", menuPrefs.infraDockVisible);
    setCheckState("design.tunnels", menuPrefs.showTunnels);
}

function setCheckState(action, on) {
    const btn = document.querySelector(`.dropdown-item[data-action="${action}"]`);
    if (btn) btn.classList.toggle("checked", !!on);
}

function executeMenuAction(action) {
    switch (action) {
        case "file.switchOrg":
            openOrganizationManager();
            break;
        case "file.switchProject":
            openProjectManager();
            break;
        case "file.save":
            saveWorkspace();
            break;
        case "file.reload":
            location.reload();
            break;
        case "file.export":
            exportSceneSnapshot();
            break;
        case "file.import":
            ingestDrillholes();
            break;
        case "edit.undo":
            pushLiveEvent("Undo: reverted last parameter change", "info");
            break;
        case "edit.redo":
            pushLiveEvent("Redo: reapplied workspace operation", "info");
            break;
        case "edit.prefs":
            showAlertBanner("Preferences: grid 25m · WGS84 UTM 50S · CUDA backend enabled", "info");
            break;
        case "view.top":
            triggerViewMode("top");
            break;
        case "view.iso":
            triggerViewMode("iso");
            break;
        case "view.reset":
            triggerResetView();
            break;
        case "view.composite":
            menuPrefs.compositeView = !menuPrefs.compositeView;
            viewportMode = menuPrefs.compositeView ? "composite" : "module";
            syncMenuCheckStates();
            updateViewportHUD();
            pushLiveEvent(menuPrefs.compositeView ? "Composite digital twin viewport enabled" : "Module viewport restored", "info");
            break;
        case "view.infra":
            menuPrefs.infraDockVisible = !menuPrefs.infraDockVisible;
            toggleInfraDock(menuPrefs.infraDockVisible);
            syncMenuCheckStates();
            break;
        case "view.manual":
            toggleManual();
            break;
        case "module.geology":
            loadModule("geology");
            break;
        case "module.blockmodel":
            loadModule("blockmodel");
            break;
        case "module.engineering":
            loadModule("engineering");
            break;
        case "module.simulation":
            loadModule("simulation");
            break;
        case "strata.slice":
            loadModule("geology");
            geologySliceOffset = (geologySliceOffset + 20) % 120;
            injectParameters("geology");
            pushLiveEvent(`Strata slice offset: ${geologySliceOffset}m`, "info");
            break;
        case "strata.ingest":
            loadModule("geology");
            runMenuPipeline("Drillhole Ingestion", "geology", [
                "Streaming collar survey from field MQTT bus…",
                "Validating assay tables (Au, Cu)…",
                "Updating geological model & twin cache…"
            ]);
            break;
        case "strata.kriging":
            loadModule("geology");
            runMenuPipeline("Kriging Interpolation", "geology", [
                "AI Agent: variogram model selection…",
                "GPU cluster: Ordinary Kriging CUDA kernels…",
                "Publishing grade shell to block model…"
            ]);
            break;
        case "blocks.optimize":
            loadModule("blockmodel");
            blockGradeCutoff = Math.min(4.5, blockGradeCutoff + 0.3);
            injectParameters("blockmodel");
            runMenuPipeline("Block Model Optimization", "blockmodel");
            break;
        case "blocks.gpuKriging":
            loadModule("blockmodel");
            runMenuPipeline("Distributed GPU Kriging", "blockmodel");
            break;
        case "design.stope":
            triggerStopeOptimizationFull();
            break;
        case "design.slope":
            loadModule("engineering");
            runMenuPipeline("Slope Safety Analysis", "engineering");
            showAlertBanner("Slope stability SF=1.14 on bench 3 — review geotech constraints", "warn");
            break;
        case "design.tunnels":
            menuPrefs.showTunnels = !menuPrefs.showTunnels;
            showUndergroundTunnels = menuPrefs.showTunnels;
            syncMenuCheckStates();
            pushLiveEvent(showUndergroundTunnels ? "Underground tunnel mesh visible" : "Tunnels hidden", "info");
            break;
        case "sim.restart":
            loadModule("simulation");
            resetSimulation();
            pushLiveEvent("Fleet dispatch simulation restarted", "success");
            break;
        case "sim.gpuQueue":
            loadModule("simulation");
            assignGpuSimulationQueue();
            break;
        case "help.manual":
            toggleManual();
            switchManualTab("overview");
            break;
        case "help.shortcuts":
            toggleManual();
            switchManualTab("controls");
            break;
        case "help.about":
            showAlertBanner("NGMEP v5.1 — Multi-tenant mining engineering platform (per-organization projects)", "info");
            break;
        default:
            pushLiveEvent(`Unknown action: ${action}`, "warn");
    }
}

function runMenuPipeline(label, module, extraSteps) {
    if (typeof runOrchestrationPipeline === "function") {
        runOrchestrationPipeline(label, module, () => loadModule(module));
    }
    if (extraSteps && typeof appendAITerminal === "function") {
        extraSteps.forEach(s => appendAITerminal(s, "system-msg"));
    }
}

function saveWorkspace() {
    try {
        if (typeof saveCurrentProjectWorkspace === "function" && saveCurrentProjectWorkspace()) {
            const p = typeof getActiveProject === "function" ? getActiveProject() : null;
            const name = p ? p.name : "project";
            pushLiveEvent(`Project workspace saved: ${name}`, "success");
            showAlertBanner(`Saved to project: ${name}`, "success");
            return;
        }
        showAlertBanner("No active project — open or create a project first", "warn");
    } catch (e) {
        showAlertBanner("Save failed: " + e.message, "warn");
    }
}

function loadWorkspaceFromStorage() {
    if (typeof initTenancy === "function") {
        initTenancy();
        return;
    }
}

function exportSceneSnapshot() {
    if (!canvasEl) return;
    const link = document.createElement("a");
    const proj = typeof getActiveProject === "function" ? getActiveProject() : null;
    const slug = proj ? proj.name.replace(/\W+/g, "-").slice(0, 24) : "scene";
    link.download = `ngmep-${slug}-${Date.now()}.png`;
    link.href = canvasEl.toDataURL("image/png");
    link.click();
    pushLiveEvent("Scene snapshot exported (PNG)", "success");
}

async function ingestDrillholes() {
    loadModule("geology");
    setModuleState("geology", "loading");

    const sampleRecords = [
        { holeId: "DDH-" + Math.floor(Math.random() * 900 + 100), easting: 612300 + Math.random() * 200, northing: 7890100 + Math.random() * 200, elevation: 400 + Math.random() * 20, au_gt: +(Math.random() * 4).toFixed(2) },
        { holeId: "DDH-" + Math.floor(Math.random() * 900 + 100), easting: 612300 + Math.random() * 200, northing: 7890100 + Math.random() * 200, elevation: 400 + Math.random() * 20, au_gt: +(Math.random() * 4).toFixed(2) }
    ];

    if (typeof isApiEnabled === "function" && isApiEnabled() && typeof ingestDrillholesToApi === "function") {
        try {
            const result = await ingestDrillholesToApi(sampleRecords, "Menu ingest batch");
            pushLiveEvent(`API: ${result.recordCount} collars stored (${result.id})`, "success");
        } catch (err) {
            pushLiveEvent("API ingest failed: " + err.message, "warn");
        }
    } else {
        pushLiveEvent("Ingesting drillhole collar + assay feed (local)…", "info");
    }

    scaleMetrics.scanVolumePB += 0.002;
    setTimeout(() => {
        setModuleState("geology", "computing");
        pushLiveEvent("+ collars ingested · QA/QC passed", "success");
    }, 1200);
    setTimeout(() => setModuleState("geology", "idle"), 3500);
    runMenuPipeline("Drillhole Ingestion", "geology");
}

function toggleInfraDock(visible) {
    const dock = document.getElementById("infraDock");
    if (dock) dock.classList.toggle("hidden", !visible);
}

function handleMenuShortcuts(e) {
    if (e.ctrlKey && e.key === "s") {
        e.preventDefault();
        saveWorkspace();
    }
}

function updateViewportHUD() {
    const modeEl = document.getElementById("viewportModeLabel");
    const badge = document.querySelector("#viewportTitleHUD .active-badge");
    if (modeEl) {
        modeEl.textContent = viewportMode === "composite"
            ? "COMPOSITE DIGITAL TWIN"
            : "MODULE VIEW";
    }
    if (badge && viewportMode === "composite") {
        badge.textContent = "TWIN SYNC ACTIVE";
        badge.style.color = "var(--color-amber)";
    } else if (badge) {
        badge.textContent = "WORKSPACE DEPLOYED";
        badge.style.color = "";
    }
}

window.addEventListener("DOMContentLoaded", () => {
    initMenuBar();
});
