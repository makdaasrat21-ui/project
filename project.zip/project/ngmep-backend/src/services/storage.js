const fs = require("fs");
const path = require("path");
const { v4: uuidv4 } = require("uuid");
const { DATA_DIR, DATASET_TYPES } = require("../config");

function orgDir(orgId) {
  return path.join(DATA_DIR, "orgs", orgId);
}

function projectDir(orgId, projectId) {
  return path.join(orgDir(orgId), "projects", projectId);
}

function datasetsDir(orgId, projectId, type) {
  return path.join(projectDir(orgId, projectId), "datasets", type);
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function readJson(filePath, fallback = null) {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch (err) {
    const e = new Error(`Failed to read ${filePath}: ${err.message}`);
    e.status = 500;
    throw e;
  }
}

function writeJson(filePath, data) {
  ensureDir(path.dirname(filePath));
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf8");
}

function registryPath() {
  return path.join(DATA_DIR, "registry.json");
}

function loadRegistry() {
  return readJson(registryPath(), { organizations: [] });
}

function saveRegistry(reg) {
  writeJson(registryPath(), reg);
}

function orgMetaPath(orgId) {
  return path.join(orgDir(orgId), "org.json");
}

function projectMetaPath(orgId, projectId) {
  return path.join(projectDir(orgId, projectId), "project.json");
}

function workspacePath(orgId, projectId) {
  return path.join(projectDir(orgId, projectId), "workspace.json");
}

function listOrganizations() {
  const reg = loadRegistry();
  return reg.organizations.map(o => {
    const meta = readJson(orgMetaPath(o.id), o);
    const projectsDir = path.join(orgDir(o.id), "projects");
    let projectCount = 0;
    if (fs.existsSync(projectsDir)) {
      projectCount = fs.readdirSync(projectsDir, { withFileTypes: true })
        .filter(d => d.isDirectory()).length;
    }
    return { ...meta, projectCount };
  });
}

function getOrganization(orgId) {
  const reg = loadRegistry();
  if (!reg.organizations.find(o => o.id === orgId)) {
    const err = new Error(`Organization not found: ${orgId}`);
    err.status = 404;
    throw err;
  }
  return readJson(orgMetaPath(orgId));
}

function createOrganization(body) {
  const reg = loadRegistry();
  const id = `org_${uuidv4().slice(0, 8)}`;
  const org = {
    id,
    name: (body.name || "Untitled Company").trim(),
    license: body.license || "NGMEP-PRO",
    cloudRegion: body.cloudRegion || "ap-southeast-2",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  reg.organizations.push({ id: org.id, name: org.name });
  saveRegistry(reg);
  ensureDir(orgDir(id));
  writeJson(orgMetaPath(id), org);
  return org;
}

function listProjects(orgId) {
  getOrganization(orgId);
  const base = path.join(orgDir(orgId), "projects");
  if (!fs.existsSync(base)) return [];
  return fs.readdirSync(base, { withFileTypes: true })
    .filter(d => d.isDirectory())
    .map(d => readJson(projectMetaPath(orgId, d.name)))
    .filter(Boolean);
}

function getProject(orgId, projectId) {
  getOrganization(orgId);
  const meta = readJson(projectMetaPath(orgId, projectId));
  if (!meta) {
    const err = new Error(`Project not found: ${projectId}`);
    err.status = 404;
    throw err;
  }
  return meta;
}

const TEMPLATES = {
  blank: {
    commodity: "Au",
    depositType: "open-pit",
    utmZone: "50S",
    gridSizeM: 25,
    sites: [{ name: "Site A", x: 50, y: 50, active: true }],
    blocksIndexed: 120000000,
    scanVolumePB: 0.12,
    cloudRegions: 1,
    gpuNodes: 4
  },
  gold_open_pit: {
    commodity: "Au",
    depositType: "open-pit",
    utmZone: "50S",
    gridSizeM: 25,
    sites: [
      { name: "Main Pit", x: 50, y: 50, active: true },
      { name: "North Extension", x: 30, y: 35, active: false }
    ],
    blocksIndexed: 890000000,
    scanVolumePB: 0.45,
    cloudRegions: 2,
    gpuNodes: 8
  },
  copper_underground: {
    commodity: "Cu",
    depositType: "underground",
    utmZone: "19S",
    gridSizeM: 15,
    sites: [
      { name: "Decline 1", x: 45, y: 55, active: true },
      { name: "Stope Block B", x: 60, y: 48, active: true }
    ],
    blocksIndexed: 420000000,
    scanVolumePB: 0.28,
    cloudRegions: 2,
    gpuNodes: 6
  },
  iron_multi_site: {
    commodity: "Fe",
    depositType: "open-pit",
    utmZone: "50S",
    gridSizeM: 50,
    sites: [
      { name: "Pit North", x: 25, y: 40, active: true },
      { name: "Pit South", x: 55, y: 65, active: true }
    ],
    blocksIndexed: 2100000000,
    scanVolumePB: 1.2,
    cloudRegions: 3,
    gpuNodes: 12
  }
};

function createProject(orgId, body) {
  getOrganization(orgId);
  const tpl = TEMPLATES[body.template] || TEMPLATES.blank;
  const id = `proj_${uuidv4().slice(0, 8)}`;
  const now = new Date().toISOString();
  const project = {
    id,
    orgId,
    name: (body.name || tpl.name || "New Project").trim(),
    template: body.template || "blank",
    commodity: body.commodity || tpl.commodity,
    depositType: body.depositType || tpl.depositType,
    utmZone: body.utmZone || tpl.utmZone,
    gridSizeM: body.gridSizeM ?? tpl.gridSizeM,
    sites: body.sites || tpl.sites,
    blocksIndexed: body.blocksIndexed ?? tpl.blocksIndexed,
    scanVolumePB: body.scanVolumePB ?? tpl.scanVolumePB,
    cloudRegions: body.cloudRegions ?? tpl.cloudRegions,
    gpuNodes: body.gpuNodes ?? tpl.gpuNodes,
    createdAt: now,
    updatedAt: now
  };
  ensureDir(projectDir(orgId, id));
  DATASET_TYPES.forEach(t => ensureDir(datasetsDir(orgId, id, t)));
  writeJson(projectMetaPath(orgId, id), project);
  return project;
}

function updateProject(orgId, projectId, patch) {
  const project = getProject(orgId, projectId);
  const updated = {
    ...project,
    ...patch,
    id: project.id,
    orgId: project.orgId,
    updatedAt: new Date().toISOString()
  };
  writeJson(projectMetaPath(orgId, projectId), updated);
  return updated;
}

function getWorkspace(orgId, projectId) {
  getProject(orgId, projectId);
  return readJson(workspacePath(orgId, projectId), null);
}

function saveWorkspace(orgId, projectId, workspace) {
  getProject(orgId, projectId);
  const payload = {
    ...workspace,
    savedAt: new Date().toISOString()
  };
  writeJson(workspacePath(orgId, projectId), payload);
  return payload;
}

function listDatasets(orgId, projectId, type) {
  getProject(orgId, projectId);
  if (!DATASET_TYPES.includes(type)) {
    const err = new Error(`Invalid dataset type. Allowed: ${DATASET_TYPES.join(", ")}`);
    err.status = 400;
    throw err;
  }
  const dir = datasetsDir(orgId, projectId, type);
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .filter(f => f.endsWith(".json"))
    .map(f => {
      const meta = readJson(path.join(dir, f));
      return {
        id: meta.id,
        name: meta.name,
        type: meta.type,
        recordCount: meta.recordCount,
        createdAt: meta.createdAt,
        updatedAt: meta.updatedAt
      };
    });
}

function getDataset(orgId, projectId, type, datasetId) {
  listDatasets(orgId, projectId, type); // validates type + project
  const file = path.join(datasetsDir(orgId, projectId, type), `${datasetId}.json`);
  const data = readJson(file);
  if (!data) {
    const err = new Error(`Dataset not found: ${datasetId}`);
    err.status = 404;
    throw err;
  }
  return data;
}

function ingestDataset(orgId, projectId, type, body, options = {}) {
  getProject(orgId, projectId);
  if (!DATASET_TYPES.includes(type)) {
    const err = new Error(`Invalid dataset type. Allowed: ${DATASET_TYPES.join(", ")}`);
    err.status = 400;
    throw err;
  }

  const id = body.id || `ds_${uuidv4().slice(0, 8)}`;
  const now = new Date().toISOString();
  const records = body.records || body.data || body.rows || [];
  const payload = {
    id,
    orgId,
    projectId,
    type,
    name: body.name || `${type} ${now.slice(0, 10)}`,
    format: body.format || "json",
    source: body.source || options.source || "api",
    schema: body.schema || inferSchema(records),
    records: Array.isArray(records) ? records : [records],
    recordCount: Array.isArray(records) ? records.length : 1,
    metadata: body.metadata || {},
    createdAt: body.createdAt || now,
    updatedAt: now
  };

  ensureDir(datasetsDir(orgId, projectId, type));
  writeJson(path.join(datasetsDir(orgId, projectId, type), `${id}.json`), payload);

  // bump project stats for drillholes / blockmodel
  if (type === "drillholes" && payload.recordCount) {
    const proj = getProject(orgId, projectId);
    updateProject(orgId, projectId, {
      lastDrillholeIngest: now,
      drillholeCount: (proj.drillholeCount || 0) + payload.recordCount
    });
  }

  return payload;
}

function deleteDataset(orgId, projectId, type, datasetId) {
  getDataset(orgId, projectId, type, datasetId);
  const file = path.join(datasetsDir(orgId, projectId, type), `${datasetId}.json`);
  fs.unlinkSync(file);
  return { deleted: datasetId };
}

function inferSchema(records) {
  if (!records.length || typeof records[0] !== "object") return {};
  return Object.keys(records[0]).reduce((acc, k) => {
    acc[k] = typeof records[0][k];
    return acc;
  }, {});
}

function getProjectBundle(orgId, projectId) {
  const project = getProject(orgId, projectId);
  const workspace = getWorkspace(orgId, projectId);
  const datasets = {};
  DATASET_TYPES.forEach(type => {
    datasets[type] = listDatasets(orgId, projectId, type);
  });
  return { organization: getOrganization(orgId), project, workspace, datasets };
}

module.exports = {
  DATASET_TYPES,
  listOrganizations,
  getOrganization,
  createOrganization,
  listProjects,
  getProject,
  createProject,
  updateProject,
  getWorkspace,
  saveWorkspace,
  listDatasets,
  getDataset,
  ingestDataset,
  deleteDataset,
  getProjectBundle
};
