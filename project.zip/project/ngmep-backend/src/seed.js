const storage = require("./services/storage");

const DEMOS = [
  { org: "Apex Mining Corp", license: "NGMEP-ENTERPRISE", projects: [
    { name: "Sunrise Gold OP", template: "gold_open_pit" }
  ]},
  { org: "Continental Resources", license: "NGMEP-ENTERPRISE", projects: [
    { name: "Hematite North", template: "iron_multi_site" }
  ]},
  { org: "Kopano Minerals (Pty)", license: "NGMEP-PRO", projects: [
    { name: "Maseve UG Cu", template: "copper_underground" }
  ]}
];

const SAMPLE_DRILLHOLES = [
  { holeId: "BH_001", easting: 612340.5, northing: 7890123.2, elevation: 412.0, depth: 185.5, au_gt: 2.4 },
  { holeId: "BH_002", easting: 612380.1, northing: 7890150.8, elevation: 408.5, depth: 220.0, au_gt: 0.8 },
  { holeId: "BH_003", easting: 612295.0, northing: 7890088.0, elevation: 415.2, depth: 150.0, au_gt: 4.1 }
];

function seed() {
  console.log("Seeding NGMEP backend…");
  DEMOS.forEach(d => {
    const org = storage.createOrganization({ name: d.org, license: d.license });
    d.projects.forEach(p => {
      const project = storage.createProject(org.id, { name: p.name, template: p.template });
      storage.ingestDataset(org.id, project.id, "drillholes", {
        name: "Initial collar set",
        records: SAMPLE_DRILLHOLES
      });
      storage.saveWorkspace(org.id, project.id, {
        activeEngine: project.depositType === "underground" ? "engineering" : "geology",
        yaw: 45, pitch: 35, zoom: 1.0,
        blockGradeCutoff: project.commodity === "Au" ? 0.5 : 1.0
      });
      console.log(`  + ${org.name} / ${project.name}`);
    });
  });
  console.log("Done.");
}

if (require.main === module) seed();

module.exports = { seed };
