const express = require("express");
const cors = require("cors");
const path = require("path");
const { PORT, CORS_ORIGIN, DATA_DIR } = require("./config");
const apiRoutes = require("./routes");
const { requestLog } = require("./middleware/requestLog");
const { errorHandler } = require("./middleware/errorHandler");

const app = express();

app.use(requestLog);
app.use(cors({
  origin: CORS_ORIGIN.includes("*") ? true : CORS_ORIGIN,
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "X-NGMEP-Source", "X-Org-Id", "X-Project-Id"]
}));
app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));

app.get("/", (req, res) => {
  res.json({
    name: "NGMEP Backend API",
    docs: "/api/v1/health",
    dataDirectory: DATA_DIR,
    endpoints: {
      organizations: "GET/POST /api/v1/organizations",
      projects: "GET/POST /api/v1/organizations/:orgId/projects",
      workspace: "GET/PUT /api/v1/organizations/:orgId/projects/:projectId/workspace",
      datasets: "GET/POST /api/v1/organizations/:orgId/projects/:projectId/datasets/:type",
      upload: "POST /api/v1/organizations/:orgId/projects/:projectId/datasets/:type/upload",
      sync: "GET /api/v1/organizations/:orgId/projects/:projectId/sync"
    }
  });
});

app.use("/api/v1", apiRoutes);
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`NGMEP Backend listening on http://localhost:${PORT}`);
  console.log(`Data directory: ${DATA_DIR}`);
  console.log(`API base: http://localhost:${PORT}/api/v1`);
});
