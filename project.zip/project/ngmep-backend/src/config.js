const path = require("path");
require("dotenv").config();

const PORT = parseInt(process.env.PORT || "8787", 10);
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, "..", "data"));
const CORS_ORIGIN = (process.env.CORS_ORIGIN || "*")
  .split(",")
  .map(s => s.trim())
  .filter(Boolean);

const DATASET_TYPES = ["drillholes", "blockmodel", "telemetry", "simulation", "mesh", "economics"];

module.exports = { PORT, DATA_DIR, CORS_ORIGIN, DATASET_TYPES };
