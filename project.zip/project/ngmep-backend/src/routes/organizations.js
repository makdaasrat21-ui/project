const express = require("express");
const storage = require("../services/storage");

const router = express.Router();

router.get("/", (req, res, next) => {
  try {
    res.json({ organizations: storage.listOrganizations() });
  } catch (e) { next(e); }
});

router.post("/", (req, res, next) => {
  try {
    const org = storage.createOrganization(req.body);
    res.status(201).json(org);
  } catch (e) { next(e); }
});

router.get("/:orgId", (req, res, next) => {
  try {
    res.json(storage.getOrganization(req.params.orgId));
  } catch (e) { next(e); }
});

router.get("/:orgId/projects", (req, res, next) => {
  try {
    res.json({ projects: storage.listProjects(req.params.orgId) });
  } catch (e) { next(e); }
});

router.post("/:orgId/projects", (req, res, next) => {
  try {
    const project = storage.createProject(req.params.orgId, req.body);
    res.status(201).json(project);
  } catch (e) { next(e); }
});

module.exports = router;
