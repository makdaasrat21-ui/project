const express = require("express");
const storage = require("../services/storage");

const router = express.Router({ mergeParams: true });

router.get("/:projectId", (req, res, next) => {
  try {
    res.json(storage.getProject(req.params.orgId, req.params.projectId));
  } catch (e) { next(e); }
});

router.patch("/:projectId", (req, res, next) => {
  try {
    res.json(storage.updateProject(req.params.orgId, req.params.projectId, req.body));
  } catch (e) { next(e); }
});

router.get("/:projectId/bundle", (req, res, next) => {
  try {
    res.json(storage.getProjectBundle(req.params.orgId, req.params.projectId));
  } catch (e) { next(e); }
});

router.get("/:projectId/workspace", (req, res, next) => {
  try {
    const workspace = storage.getWorkspace(req.params.orgId, req.params.projectId);
    res.json({ workspace });
  } catch (e) { next(e); }
});

router.put("/:projectId/workspace", (req, res, next) => {
  try {
    const workspace = storage.saveWorkspace(
      req.params.orgId,
      req.params.projectId,
      req.body.workspace || req.body
    );
    res.json({ workspace });
  } catch (e) { next(e); }
});

module.exports = router;
