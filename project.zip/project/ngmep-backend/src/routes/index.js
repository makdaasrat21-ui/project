const express = require("express");
const organizations = require("./organizations");
const projects = require("./projects");
const datasets = require("./datasets");
const storage = require("../services/storage");
const { DATASET_TYPES } = require("../config");

const router = express.Router();

router.get("/health", (req, res) => {
  res.json({
    status: "ok",
    service: "ngmep-backend",
    version: "1.0.0",
    datasetTypes: DATASET_TYPES
  });
});

router.use("/organizations", organizations);
router.use("/organizations/:orgId/projects", projects);
router.use("/organizations/:orgId/projects/:projectId/datasets", datasets);

/** Quick session: org + project + all data for frontend sync */
router.get("/organizations/:orgId/projects/:projectId/sync", (req, res, next) => {
  try {
    res.json(storage.getProjectBundle(req.params.orgId, req.params.projectId));
  } catch (e) { next(e); }
});

module.exports = router;
