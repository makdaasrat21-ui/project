const express = require("express");
const multer = require("multer");
const storage = require("../services/storage");
const { DATASET_TYPES } = require("../config");

const router = express.Router({ mergeParams: true });
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 50 * 1024 * 1024 } });

/** GET /types — list allowed dataset kinds */
router.get("/types", (req, res) => {
  res.json({
    types: DATASET_TYPES,
    description: {
      drillholes: "Collar, survey, assay tables",
      blockmodel: "Block grades, dimensions, attributes",
      telemetry: "Sensors, production, slope monitoring",
      simulation: "Fleet dispatch, haulage, optimization results",
      mesh: "Surfaces, pit shells, triangulations",
      economics: "Cashflow, NPV, cost models"
    }
  });
});

/** GET /:type — list datasets of a type */
router.get("/:type", (req, res, next) => {
  try {
    const items = storage.listDatasets(req.params.orgId, req.params.projectId, req.params.type);
    res.json({ type: req.params.type, datasets: items });
  } catch (e) { next(e); }
});

/** GET /:type/:datasetId — retrieve full dataset */
router.get("/:type/:datasetId", (req, res, next) => {
  try {
    res.json(storage.getDataset(
      req.params.orgId,
      req.params.projectId,
      req.params.type,
      req.params.datasetId
    ));
  } catch (e) { next(e); }
});

/** POST /:type — ingest JSON body */
router.post("/:type", (req, res, next) => {
  try {
    const result = storage.ingestDataset(
      req.params.orgId,
      req.params.projectId,
      req.params.type,
      req.body,
      { source: req.get("X-NGMEP-Source") || "api-json" }
    );
    res.status(201).json(result);
  } catch (e) { next(e); }
});

/** POST /:type/upload — ingest CSV or JSON file */
router.post("/:type/upload", upload.single("file"), (req, res, next) => {
  try {
    if (!req.file) {
      const err = new Error("No file uploaded. Use form field 'file'.");
      err.status = 400;
      throw err;
    }

    const text = req.file.buffer.toString("utf8");
    let records;
    let format = "json";

    if (req.file.originalname.endsWith(".csv") || req.file.mimetype === "text/csv") {
      format = "csv";
      records = parseSimpleCsv(text);
    } else {
      const parsed = JSON.parse(text);
      records = Array.isArray(parsed) ? parsed : parsed.records || parsed.data || [parsed];
    }

    const result = storage.ingestDataset(
      req.params.orgId,
      req.params.projectId,
      req.params.type,
      {
        name: req.body.name || req.file.originalname,
        format,
        records,
        metadata: { filename: req.file.originalname, size: req.file.size }
      },
      { source: "file-upload" }
    );
    res.status(201).json(result);
  } catch (e) { next(e); }
});

/** DELETE /:type/:datasetId */
router.delete("/:type/:datasetId", (req, res, next) => {
  try {
    res.json(storage.deleteDataset(
      req.params.orgId,
      req.params.projectId,
      req.params.type,
      req.params.datasetId
    ));
  } catch (e) { next(e); }
});

function parseSimpleCsv(text) {
  const lines = text.trim().split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) return [];
  const headers = lines[0].split(",").map(h => h.trim());
  return lines.slice(1).map(line => {
    const vals = line.split(",");
    const row = {};
    headers.forEach((h, i) => { row[h] = vals[i]?.trim(); });
    return row;
  });
}

module.exports = router;
