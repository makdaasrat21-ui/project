function errorHandler(err, req, res, next) {
  const status = err.status || 500;
  const message = err.message || "Internal server error";
  if (status >= 500) console.error("[NGMEP API]", err);
  res.status(status).json({
    error: true,
    message,
    path: req.originalUrl
  });
}

module.exports = { errorHandler };
