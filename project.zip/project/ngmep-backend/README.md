# NGMEP Backend API

Separate server for **feeding data in** and **retrieving data out** of NGMEP. The web client (`ngmep-platform/`) talks to this API when configured.

## Quick start

```bash
cd ngmep-backend
npm install
cp .env.example .env
npm run seed
npm run dev
```

Server: **http://localhost:8787**

## Data layout (on disk)

```
data/
  registry.json
  orgs/
    org_xxxxxxxx/
      org.json
      projects/
        proj_xxxxxxxx/
          project.json
          workspace.json
          datasets/
            drillholes/
            blockmodel/
            telemetry/
            simulation/
            mesh/
            economics/
```

## API overview

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/v1/health` | Health check |
| GET | `/api/v1/organizations` | List companies |
| POST | `/api/v1/organizations` | Create company |
| GET | `/api/v1/organizations/:orgId/projects` | List projects |
| POST | `/api/v1/organizations/:orgId/projects` | Create project |
| GET | `/api/v1/organizations/:orgId/projects/:projectId/sync` | Full bundle (project + workspace + dataset index) |
| GET/PUT | `.../workspace` | Load/save viewport & engine state |
| GET | `.../datasets/types` | Allowed dataset kinds |
| GET | `.../datasets/:type` | List datasets |
| GET | `.../datasets/:type/:id` | **Get data out** |
| POST | `.../datasets/:type` | **Feed data in** (JSON body) |
| POST | `.../datasets/:type/upload` | **Feed file in** (CSV/JSON, field `file`) |
| DELETE | `.../datasets/:type/:id` | Remove dataset |

### Dataset types

- `drillholes` — collar, survey, assay
- `blockmodel` — blocks, grades
- `telemetry` — sensors, production
- `simulation` — fleet, optimization output
- `mesh` — surfaces, pit shells
- `economics` — NPV, cashflow

## Examples

### Ingest drillholes (JSON)

```bash
curl -X POST http://localhost:8787/api/v1/organizations/ORG_ID/projects/PROJ_ID/datasets/drillholes \
  -H "Content-Type: application/json" \
  -d "{\"name\":\"Phase 2 collars\",\"records\":[{\"holeId\":\"DDH-10\",\"easting\":100,\"northing\":200,\"elevation\":300,\"au_gt\":1.2}]}"
```

### Upload CSV

```bash
curl -X POST http://localhost:8787/api/v1/organizations/ORG_ID/projects/PROJ_ID/datasets/drillholes/upload \
  -F "file=@collars.csv" -F "name=Collar import"
```

### Get data out

```bash
curl http://localhost:8787/api/v1/organizations/ORG_ID/projects/PROJ_ID/datasets/drillholes/DS_ID
```

### Save workspace from client

```bash
curl -X PUT http://localhost:8787/api/v1/organizations/ORG_ID/projects/PROJ_ID/workspace \
  -H "Content-Type: application/json" \
  -d "{\"activeEngine\":\"geology\",\"yaw\":45,\"zoom\":1.2}"
```

## Connect the frontend

In `ngmep-platform`, set before loading scripts (or in browser console):

```javascript
localStorage.setItem("ngmep_api_url", "http://localhost:8787");
```

Reload the app — it will sync organizations/projects from the API when online.

## Environment

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `8787` | HTTP port |
| `DATA_DIR` | `./data` | Persistent storage root |
| `CORS_ORIGIN` | `*` | Allowed browser origins (comma-separated) |
